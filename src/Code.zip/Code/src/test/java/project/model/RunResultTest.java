package project.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import project.util.AlgorithmType;

public class RunResultTest {
	
	private RunResult result;
	
	private int id = 5;
	private int dataSetConfigId = 2;
	private int tests = 700;
	private int successful = 650;
	private AlgorithmType algorithm = AlgorithmType.KNN;
	private int [] columnsToUse = {0,1,2,3,4,5};
	private int predictionColumn = 6;
	private int [] splitPoints = null;
	private String formula = "euclidean";
	private int k = 7;

	@Before
	public void setUp() throws Exception {
		result = new RunResult(tests, successful, algorithm);
		result.setId(id);
		result.setDataSetConfigId(dataSetConfigId);
		result.setColumnsToUse(columnsToUse);
		result.setSplitPoints(splitPoints);
		result.setPredictionColumn(predictionColumn);
		result.setK(k);
		result.setFormula(formula);
	}

	@Test
	public void testRunResult() {
		assertEquals(id, result.getId());
		assertEquals(dataSetConfigId, result.getDataSetConfigId());
		assertEquals(tests, result.getTests());
		assertEquals(successful, result.getSuccessful());
		assertEquals(algorithm, result.getAlgorithm());
		assertEquals(columnsToUse, result.getColumnsToUse());
		assertEquals(predictionColumn, result.getPredictionColumn());
		assertEquals(splitPoints, result.getSplitPoints());
		assertEquals(formula, result.getFormula());
		assertEquals(k, result.getK());
	}
}
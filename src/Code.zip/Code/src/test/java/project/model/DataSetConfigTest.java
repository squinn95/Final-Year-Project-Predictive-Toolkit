package project.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DataSetConfigTest {
	
	private DataSetConfig config;
	
	private boolean partitionTrainSet = true;
	private boolean headings = true;
	private String encodedTrainSet = "testString";
	private String encodedValidationSet = null;
	private String name = "Cars";

	@Before
	public void setUp() throws Exception {
		config = new DataSetConfig(partitionTrainSet, encodedTrainSet, encodedValidationSet, headings, name);
	}

	@Test
	public void testDataSetConfig() {
		assertEquals(partitionTrainSet, config.getPartitionTrainSet());
		assertEquals(encodedTrainSet, config.getEncodedTrainSet());
		assertEquals(encodedValidationSet, config.getEncodedValidationSet());
		assertEquals(headings, config.getHeadings());
		assertEquals(name, config.getName());
	}
}
package project.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DataSetTest {
	
	private DataSet dataset;
	
	private ArrayList<ArrayList<Double>> trainSet = new ArrayList<ArrayList<Double>>();
	private ArrayList<ArrayList<Double>> validationSet = new ArrayList<ArrayList<Double>>();
	private HashMap<String,Integer> headingsMap = new HashMap<String,Integer>();
	private int id = 123;
	private String name = "data set name";

	/*
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass");
	}
*/
	@Before
	public void setUp() throws Exception {
		dataset = new DataSet(trainSet, validationSet, id, name,headingsMap);
		//System.out.println("setUp");
	}
/*
	@After
	public void tearDown() throws Exception {
		System.out.println("tearDown");
	}
*/
	@Test
	public void testDataSet() {
		assertEquals(id, dataset.getId());
		assertEquals(name, dataset.getName());
		assertEquals(trainSet, dataset.getTrainSet());
		assertEquals(validationSet, dataset.getValidationSet());
		assertEquals(headingsMap, dataset.getHeadingsMap());
	}
}

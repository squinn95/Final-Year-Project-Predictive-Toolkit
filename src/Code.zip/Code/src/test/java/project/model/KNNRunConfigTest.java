package project.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class KNNRunConfigTest {
	
	private KNNRunConfig config;
	
	private int dataSetConfigId = 1;
	private int [] columnsToUse = {0,1,2,3,4,5};
	private int predictionColumn = 6;
	private int [] splitPoints = null;
	private String formula = "euclidean";
	private int k = 5;

	@Before
	public void setUp() throws Exception {
		config = new KNNRunConfig(dataSetConfigId, columnsToUse, predictionColumn, splitPoints,formula,k);
	}

	@Test
	public void testKNNRunConfig() {
		assertEquals(dataSetConfigId, config.getDataSetConfigId());
		assertEquals(columnsToUse, config.getColumnsToUse());
		assertEquals(predictionColumn, config.getPredictionColumn());
		assertEquals(splitPoints, config.getSplitPoints());
		assertEquals(formula, config.getFormula());
		assertEquals(k, config.getK());
	}
}
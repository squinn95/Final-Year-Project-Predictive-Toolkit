package project.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import project.util.AlgorithmType;

public class RunConfigTest {
	
	private RunConfig config;
	
	private int dataSetConfigId = 1;
	private int [] columnsToUse = {0,1,2,3,4,5};
	private int predictionColumn = 6;
	private int [] splitPoints = null;

	@Before
	public void setUp() throws Exception {
		config = new RunConfig(dataSetConfigId, columnsToUse, predictionColumn, splitPoints);
	}

	@Test
	public void testRunConfig() {
		assertEquals(dataSetConfigId, config.getDataSetConfigId());
		assertEquals(columnsToUse, config.getColumnsToUse());
		assertEquals(predictionColumn, config.getPredictionColumn());
		assertEquals(splitPoints, config.getSplitPoints());
	}
}
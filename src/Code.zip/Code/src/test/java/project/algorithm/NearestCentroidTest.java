package project.algorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.junit.Test;

import project.model.DataSet;
import project.model.RunResult;
import project.util.AlgorithmType;
import static org.junit.Assert.assertEquals;

public class NearestCentroidTest{
	
	@Test
	public void testPredictClassNearestCentroid() {
		
		ArrayList<Double> Brow1 = new ArrayList<Double>(Arrays.asList(9.0, 1.0, 2.0));
		ArrayList<Double> Brow2 = new ArrayList<Double>(Arrays.asList(11.0, 5.0, 2.0));
		ArrayList<Double> Brow3 = new ArrayList<Double>(Arrays.asList(12.0, 5.0, 1.0));
		ArrayList<Double> Brow4 = new ArrayList<Double>(Arrays.asList(11.0, 11.0, 2.0));
		
		ArrayList<Double> Crow1 = new ArrayList<Double>(Arrays.asList(3.0, 4.0, 2.0));
		ArrayList<Double> Crow2 = new ArrayList<Double>(Arrays.asList(7.0, 8.0, 1.0));
		ArrayList<Double> Crow3 = new ArrayList<Double>(Arrays.asList(7.0, 8.0, 2.0));
		ArrayList<Double> Crow4 = new ArrayList<Double>(Arrays.asList(12.0, 12.0, 1.0));
		
		ArrayList<ArrayList<Double>> trainSet = new ArrayList<ArrayList<Double>>(Arrays.asList(Crow1,Crow2,Crow3,Crow4));
		ArrayList<ArrayList<Double>> validationSet = new ArrayList<ArrayList<Double>>(Arrays.asList(Brow1,Brow2,Brow3,Brow4));
	
		int id = 1;
		String name = "test";
		
		HashMap<String, Integer> headingsMap = new HashMap<String, Integer>();
		headingsMap.put("0",0);
		headingsMap.put("1",1);
		headingsMap.put("2",2);
		
		DataSet data = new DataSet(trainSet, validationSet, id, name,headingsMap); 
		int [] columnsToUse = new int []{0,1};
		int predictionColumn = 2;
		int [] splitPoints = null;
		String formula = "euclidean";
		
		RunResult result = NearestCentroid.predictClassNearestCentroid(data, columnsToUse, predictionColumn, splitPoints, formula);
		
		
		assertEquals(result.getTests(), 4);	
		assertEquals(result.getAlgorithm(), AlgorithmType.NC);
		assertEquals(result.getSuccessful(), 2);
	}
	
	@Test
	public void testGetMostCommonVal() {	
		ArrayList<Double> Brow1 = new ArrayList<Double>(Arrays.asList(9.0, 1.0, 2.0, 9.0, 9.0));
		
		assertEquals(NearestCentroid.getMostCommonVal(Brow1),new Double(9.0));
	}
	
	@Test
	public void testGetBestClass() {	
		HashMap<Double, Double> counts = new HashMap<Double,Double>();
		counts.put(9.0, 3.0);
		counts.put(2.0, 1.0);
		counts.put(1.0, 1.0);
		
		assertEquals(NearestCentroid.getBestClass(counts),new Double(9.0));
	}
	
	@Test
	public void testGetAverage() {	
		ArrayList<Double> Brow1 = new ArrayList<Double>(Arrays.asList(9.0, 1.0, 2.0, 9.0, 9.0));
		
		assertEquals(new Double(NearestCentroid.getAvg(Brow1)),new Double(6.0));
	}
	
	@Test
	public void testGetClassCentroids() {	
		
		ArrayList<Double> Brow1 = new ArrayList<Double>(Arrays.asList(9.0, 1.0, 2.0));
		ArrayList<Double> Brow2 = new ArrayList<Double>(Arrays.asList(11.0, 5.0, 2.0));
		ArrayList<Double> Brow3 = new ArrayList<Double>(Arrays.asList(12.0, 5.0, 1.0));
		ArrayList<Double> Brow4 = new ArrayList<Double>(Arrays.asList(11.0, 11.0, 2.0)); //this row is last column - classes
		ArrayList<Double> Crow1 = new ArrayList<Double>(Arrays.asList(3.0, 4.0, 2.0));
		ArrayList<Double> Crow2 = new ArrayList<Double>(Arrays.asList(7.0, 8.0, 1.0));
		ArrayList<Double> Crow3 = new ArrayList<Double>(Arrays.asList(7.0, 8.0, 2.0));
		ArrayList<Double> Crow4 = new ArrayList<Double>(Arrays.asList(12.0, 12.0, 1.0));
		
		ArrayList<ArrayList<Double>> trainSet = new ArrayList<ArrayList<Double>>(Arrays.asList(Crow1,Crow2,Crow3,Crow4,Brow1,Brow2,Brow3,Brow4));
		
		HashMap<Double, ArrayList<Double>> res = NearestCentroid.getClassCentroids(trainSet);
		
		HashMap<Double, ArrayList<Double>> comp = new HashMap<Double, ArrayList<Double>>();
		comp.put(2.0,new ArrayList<Double>(Arrays.asList(2.0, 1.0, 2.0, 1.0, 2.0, 2.0, 1.0, 2.0)));
		comp.put(11.0,new ArrayList<Double>(Arrays.asList(3.5, 7.5, 7.5, 12.0, 5.0, 8.0, 8.5, 11.0)));
		
		assertEquals(res,comp);
	}
	
	@Test
	public void testGetClassHammingCentroids() {	
		
		ArrayList<Double> Brow1 = new ArrayList<Double>(Arrays.asList(9.0, 9.0, 1.0, 2.0));
		ArrayList<Double> Brow2 = new ArrayList<Double>(Arrays.asList(11.0, 11.0, 5.0, 2.0));
		ArrayList<Double> Brow3 = new ArrayList<Double>(Arrays.asList(12.0, 12.0, 5.0, 1.0));
		ArrayList<Double> Brow4 = new ArrayList<Double>(Arrays.asList(11.0, 11.0, 11.0, 2.0)); //this row is last column - classes
		ArrayList<Double> Crow1 = new ArrayList<Double>(Arrays.asList(3.0, 3.0, 4.0, 2.0));
		ArrayList<Double> Crow2 = new ArrayList<Double>(Arrays.asList(7.0, 7.0, 8.0, 1.0));
		ArrayList<Double> Crow3 = new ArrayList<Double>(Arrays.asList(7.0, 7.0, 8.0, 2.0));
		ArrayList<Double> Crow4 = new ArrayList<Double>(Arrays.asList(12.0, 12.0, 12.0, 1.0));
		
		ArrayList<ArrayList<Double>> trainSet = new ArrayList<ArrayList<Double>>(Arrays.asList(Crow1,Crow2,Crow3,Crow4,Brow1,Brow2,Brow3,Brow4));
		
		HashMap<Double, ArrayList<Double>> res = NearestCentroid.getClassHammingCentroids(trainSet);
		
		HashMap<Double, ArrayList<Double>> comp = new HashMap<Double, ArrayList<Double>>();
		comp.put(2.0,new ArrayList<Double>(Arrays.asList(2.0, 1.0, 2.0, 1.0, 2.0, 2.0, 1.0, 2.0)));
		comp.put(11.0,new ArrayList<Double>(Arrays.asList(3.0, 7.0, 7.0, 12.0, 9.0, 11.0, 12.0, 11.0)));
				
		assertEquals(res,comp);
	}	
}
package project.algorithm;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;

import org.junit.Test;

public class DecisionTreeTest {

  //private final DecisionTree dt = new DecisionTree();

  @Test
  public void testBuildTree() {
    final ArrayList<ArrayList<Double>> trainColumns = new ArrayList<>();
    final ArrayList<Double> columnsIndex = new ArrayList<>();
    trainColumns.add(columnsIndex);

    final ArrayList<Integer> usedAttributes = new ArrayList<>();

    final Node node = new Node(trainColumns, usedAttributes);
    final String formula = "";
    final Node tree = DecisionTree.buildTree(node, formula);

    assertTrue(tree.isLeaf());
  }

  @Test
  public void testBuildTree_WITH_COLUMN_INDEX() {
    final ArrayList<ArrayList<Double>> trainColumns = new ArrayList<>();
    final ArrayList<Double> columnsIndex = new ArrayList<>();
    columnsIndex.add(1.0);
    trainColumns.add(columnsIndex);

    final ArrayList<Integer> usedAttributes = new ArrayList<>();

    final Node node = new Node(trainColumns, usedAttributes);
    final String formula = "";
    final Node tree = DecisionTree.buildTree(node, formula);

    assertTrue(tree.isLeaf());
  }

  @Test
  public void testBuildTree_WITH_USED_ATTRIBUTE() {
    final ArrayList<ArrayList<Double>> trainColumns = new ArrayList<>();
    final ArrayList<Double> columnsIndex0 = new ArrayList<>();
    columnsIndex0.add(1.0);
    columnsIndex0.add(2.0);
    trainColumns.add(columnsIndex0);
    final ArrayList<Double> columnsIndex1 = new ArrayList<>();
    columnsIndex1.add(1.0);
    columnsIndex1.add(2.0);
    trainColumns.add(columnsIndex1);

    final ArrayList<Integer> usedAttributes = new ArrayList<>();
    usedAttributes.add(1);
    usedAttributes.add(2);

    final Node node = new Node(trainColumns, usedAttributes);
    final String formula = "";
    final Node tree = DecisionTree.buildTree(node, formula);

    assertFalse(tree.isLeaf());
    assertEquals(2, tree.children.size());
    assertEquals(0, tree.getSplitIndex());
    assertEquals(3, tree.getUsedAttributes().size());
    assertEquals(1, tree.getUsedAttributes().get(0).intValue());
    assertEquals(2, tree.getUsedAttributes().get(1).intValue());
    assertEquals(0, tree.getUsedAttributes().get(2).intValue());
    assertTrue(tree.children.get(1.0).isLeaf());
    assertTrue(tree.children.get(2.0).isLeaf());
  }
}
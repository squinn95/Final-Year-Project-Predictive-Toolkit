package project.algorithm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import project.model.DataSet;
import project.model.RunResult;
import project.util.AlgorithmType;

import org.junit.Test;

public class KNNTest {
  @Test
  public void testPredictClassKNN() {
    final ArrayList<Double> Brow1 = new ArrayList<>(Arrays.asList(9.0, 1.0, 2.0));
    final ArrayList<Double> Brow2 = new ArrayList<>(Arrays.asList(11.0, 5.0, 2.0));
    final ArrayList<Double> Brow3 = new ArrayList<>(Arrays.asList(12.0, 5.0, 1.0));
    final ArrayList<Double> Brow4 = new ArrayList<>(Arrays.asList(11.0, 11.0, 2.0));

    final ArrayList<Double> Crow1 = new ArrayList<>(Arrays.asList(3.0, 4.0, 2.0));
    final ArrayList<Double> Crow2 = new ArrayList<>(Arrays.asList(7.0, 8.0, 1.0));
    final ArrayList<Double> Crow3 = new ArrayList<>(Arrays.asList(7.0, 8.0, 2.0));
    final ArrayList<Double> Crow4 = new ArrayList<>(Arrays.asList(12.0, 12.0, 1.0));

    final ArrayList<ArrayList<Double>> trainSet = new ArrayList<>(Arrays.asList(Crow1, Crow2, Crow3, Crow4));
    final ArrayList<ArrayList<Double>> validationSet = new ArrayList<>(Arrays.asList(Brow1, Brow2, Brow3, Brow4));

    final int id = 1;
    final String name = "test";

    final HashMap<String, Integer> headingsMap = new HashMap<>();
    headingsMap.put("0", 0);
    headingsMap.put("1", 1);
    headingsMap.put("2", 2);

    final DataSet data = new DataSet(trainSet, validationSet, id, name, headingsMap);
    final int[] columnsToUse = new int[] { 0, 1 };
    final int predictionColumn = 2;
    final int[] splitPoints = null;

    final int k = 3;
    final String formula = "";
    final RunResult runResult = KNN.predictClassKNN(data, columnsToUse, predictionColumn, splitPoints, k, formula);
    assertEquals(AlgorithmType.KNN, runResult.getAlgorithm());
    assertEquals(0, runResult.getId());
    assertEquals(0, runResult.getDataSetConfigId());
    assertEquals(4, runResult.getTests());
    assertNull(runResult.getColumnsToUse());
    assertEquals(0, runResult.getPredictionColumn());
    assertNull(runResult.getSplitPoints());
    assertNull(runResult.getFormula());
    assertEquals(0, runResult.getK());
    assertEquals(2, runResult.getSuccessful());
  }
}
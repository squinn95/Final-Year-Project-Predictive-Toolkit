package project.algorithm;



import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import org.junit.Test;
import project.util.Pair;
import static org.junit.Assert.assertEquals;

public class CommonMethodsTest{
	
	@Test
	public void testCreateColumnStructure() {
		ArrayList<Double> row1 = new ArrayList<Double>(Arrays.asList(1.0,2.0,3.0,4.0));
		ArrayList<Double> row2 = new ArrayList<Double>(Arrays.asList(5.0,6.0,7.0,8.0));
		ArrayList<Double> row3 = new ArrayList<Double>(Arrays.asList(9.0,10.0,11.0,12.0));
		
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(2.0,6.0,10.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0));
		
		ArrayList<ArrayList<Double>> rowStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(row1,row2,row3));
		
		ArrayList<ArrayList<Double>> colStruct = CommonMethods.createColumnStructure(rowStruct);
		
		assertEquals(col1, colStruct.get(0));
		assertEquals(col2, colStruct.get(1));
		assertEquals(col3, colStruct.get(2));
		assertEquals(col4, colStruct.get(3));	
	}
	
	@Test
	public void testCreateRowStructure() {
		ArrayList<Double> row1 = new ArrayList<Double>(Arrays.asList(1.0,2.0,3.0,4.0));
		ArrayList<Double> row2 = new ArrayList<Double>(Arrays.asList(5.0,6.0,7.0,8.0));
		ArrayList<Double> row3 = new ArrayList<Double>(Arrays.asList(9.0,10.0,11.0,12.0));
		
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(2.0,6.0,10.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0));
		
		ArrayList<ArrayList<Double>> colStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(col1,col2,col3,col4));
		
		ArrayList<ArrayList<Double>> rowStruct = CommonMethods.createRowStructure(colStruct);		

		assertEquals(row1, rowStruct.get(0));
		assertEquals(row2, rowStruct.get(1));
		assertEquals(row3, rowStruct.get(2));
	}
	
	@Test
	public void testTrimColumns() {
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(2.0,6.0,10.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0));
		ArrayList<Double> col5 = new ArrayList<Double>(Arrays.asList(1.0,2.0,3.0,4.0));
		ArrayList<Double> col6 = new ArrayList<Double>(Arrays.asList(5.0,6.0,7.0,8.0));
		ArrayList<Double> col7 = new ArrayList<Double>(Arrays.asList(9.0,10.0,11.0,12.0));
		
		ArrayList<ArrayList<Double>> colStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(col1,col2,col3,col4,col5,col6,col7));
		
		ArrayList<ArrayList<Double>> newCols = CommonMethods.trimColumns(colStruct,new int[]{0,4,6},2);
		
		assertEquals(4, newCols.size());
		assertEquals(col1, newCols.get(0));
		assertEquals(col5, newCols.get(1));
		assertEquals(col7, newCols.get(2));
		assertEquals(col3, newCols.get(3));	
	}
	
	@Test
	public void testNormaliseDataset() {
		ArrayList<Double> row1 = new ArrayList<Double>(Arrays.asList(1.0,0.2,2.0,3.0,88.0));
		ArrayList<Double> row2 = new ArrayList<Double>(Arrays.asList(5.0,0.6,10.0,9.0,55.0));
		ArrayList<Double> row3 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,33.0));
		
		ArrayList<Double> normRow1 = new ArrayList<Double>(Arrays.asList(0.0,0.0,0.0,0.0,88.0));
		ArrayList<Double> normRow2 = new ArrayList<Double>(Arrays.asList(0.4444,0.5,0.4444,0.6667,55.0));
		ArrayList<Double> normRow3 = new ArrayList<Double>(Arrays.asList(1.0,1.0,1.0,1.0,33.0));
		
		
		ArrayList<ArrayList<Double>> rowStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(row1,row2,row3));
		ArrayList<ArrayList<Double>> colStruct = CommonMethods.createColumnStructure(rowStruct);
		
		ArrayList<ArrayList<Double>> normSet = CommonMethods.normaliseDataset(rowStruct,colStruct);
		assertEquals(normRow1, normSet.get(0));
		assertEquals(normRow2, normSet.get(1));
		assertEquals(normRow3, normSet.get(2));	
		
	}
	
	@Test
	public void testClassifyDataset() {
		ArrayList<Double> row1 = new ArrayList<Double>(Arrays.asList(1.0,0.2,2.0,3.0,88.0));
		ArrayList<Double> row2 = new ArrayList<Double>(Arrays.asList(5.0,0.6,10.0,9.0,55.0));
		ArrayList<Double> row3 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,33.0));
		ArrayList<Double> row4 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,133.0));
		
		ArrayList<Double> classRow1 = new ArrayList<Double>(Arrays.asList(1.0,0.2,2.0,3.0,2.0));
		ArrayList<Double> classRow2 = new ArrayList<Double>(Arrays.asList(5.0,0.6,10.0,9.0,2.0));
		ArrayList<Double> classRow3 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,1.0));
		ArrayList<Double> classRow4 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,3.0));
		
		ArrayList<ArrayList<Double>> rowStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(row1,row2,row3,row4));
		
		ArrayList<ArrayList<Double>> classSet = CommonMethods.classifyDataset(rowStruct,new int[]{50,100});
		
		ArrayList<ArrayList<Double>> nonClassSet = CommonMethods.classifyDataset(rowStruct,null);
		
		assertEquals(classRow1, classSet.get(0));
		assertEquals(classRow2, classSet.get(1));
		assertEquals(classRow3, classSet.get(2));
		assertEquals(classRow4, classSet.get(3));
		
		assertEquals(row1, nonClassSet.get(0));
		assertEquals(row2, nonClassSet.get(1));
		assertEquals(row3, nonClassSet.get(2));
		assertEquals(row4, nonClassSet.get(3));
	
	}
	
	@Test
	public void testGetColumnCount() {
		ArrayList<Double> row1 = new ArrayList<Double>(Arrays.asList(1.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> row2 = new ArrayList<Double>(Arrays.asList(5.0,5.0,5.0,9.0,55.0));
		ArrayList<Double> row3 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,33.0));
		ArrayList<Double> row4 = new ArrayList<Double>(Arrays.asList(10.0,1.0,20.0,12.0,133.0));
		
		assertEquals(2, CommonMethods.getColumnCount(row1, 1.0));
		assertEquals(3, CommonMethods.getColumnCount(row2, 5.0));
		assertEquals(1, CommonMethods.getColumnCount(row3, 33.0));
		assertEquals(0, CommonMethods.getColumnCount(row4, 105.0));
	}
	
	@Test
	public void testGetColumnValueLocationMap() {
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(12.0,11.0,10.0,11.0,10.0,11.0,12.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0,5.0,6.0,7.0,8.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0,5.0,6.0,7.0,8.0));
		
		ArrayList<ArrayList<Double>> colStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(col1,col2,col3,col4));
		
		HashMap<Double, ArrayList<Integer>> counts = CommonMethods.getColumnValueLocationMap(colStruct,1);
		
		HashMap<Double, ArrayList<Integer>> manualCounts = new HashMap<Double, ArrayList<Integer>>();
		manualCounts.put(10.0, new ArrayList<Integer>(Arrays.asList(2,4)));
		manualCounts.put(11.0, new ArrayList<Integer>(Arrays.asList(1,3,5)));
		manualCounts.put(12.0, new ArrayList<Integer>(Arrays.asList(0,6)));
		
		assertEquals(counts, manualCounts);
	}
	
	@Test
	public void testGetIndexColumnStructuresMap() {
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0,5.0,6.0,7.0,8.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0,5.0,6.0,7.0,8.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(10.0,10.0,11.0,11.0,11.0,12.0,12.0));
		
		ArrayList<ArrayList<Double>> colStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(col1,col2,col3,col4));
		
		ArrayList<ArrayList<Double>> rowStruct = CommonMethods.createRowStructure(colStruct);	
		
		HashMap<Double, ArrayList<Integer>> counts = CommonMethods.getColumnValueLocationMap(colStruct,3);
		
		HashMap<Double,ArrayList<ArrayList<Double>>> indexColumnStruct = CommonMethods.getIndexColumnStructuresMap(rowStruct,counts);
		
		HashMap<Double,ArrayList<ArrayList<Double>>> manualIndexColumnStruct = new HashMap<Double,ArrayList<ArrayList<Double>>>();
		
		ArrayList<Double> Acol1 = new ArrayList<Double>(Arrays.asList(1.0,5.0));
		ArrayList<Double> Acol2 = new ArrayList<Double>(Arrays.asList(3.0,7.0));
		ArrayList<Double> Acol3 = new ArrayList<Double>(Arrays.asList(4.0,8.0));
		ArrayList<Double> Acol4 = new ArrayList<Double>(Arrays.asList(10.0,10.0));
		ArrayList<ArrayList<Double>> AcolStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(Acol1,Acol2,Acol3,Acol4));
		manualIndexColumnStruct.put(10.0,AcolStruct);
		
		ArrayList<Double> Bcol1 = new ArrayList<Double>(Arrays.asList(9.0, 1.0, 2.0));
		ArrayList<Double> Bcol2 = new ArrayList<Double>(Arrays.asList(11.0, 5.0, 6.0));
		ArrayList<Double> Bcol3 = new ArrayList<Double>(Arrays.asList(12.0, 5.0, 6.0));
		ArrayList<Double> Bcol4 = new ArrayList<Double>(Arrays.asList(11.0, 11.0, 11.0));
		ArrayList<ArrayList<Double>> BcolStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(Bcol1,Bcol2,Bcol3,Bcol4));
		manualIndexColumnStruct.put(11.0,BcolStruct);
		
		ArrayList<Double> Ccol1 = new ArrayList<Double>(Arrays.asList(3.0, 4.0));
		ArrayList<Double> Ccol2 = new ArrayList<Double>(Arrays.asList(7.0, 8.0));
		ArrayList<Double> Ccol3 = new ArrayList<Double>(Arrays.asList(7.0, 8.0));
		ArrayList<Double> Ccol4 = new ArrayList<Double>(Arrays.asList(12.0, 12.0));
		ArrayList<ArrayList<Double>> CcolStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(Ccol1,Ccol2,Ccol3,Ccol4));
		manualIndexColumnStruct.put(12.0,CcolStruct);		
		
		assertEquals(manualIndexColumnStruct, indexColumnStruct);		
	}
	
	@Test
	public void testGetMaxCount() {
		HashMap<Double,Double> classCounts = new HashMap<Double,Double>();
		classCounts.put(1.0, 10.0);
		classCounts.put(2.0, 15.0);
		classCounts.put(3.0, 20.0);
		classCounts.put(4.0, 28.0);
		
		Double result = CommonMethods.getMaxCount(classCounts);
		
		assertEquals(new Double(4.0), result);	
	}
	
	@Test
	public void testGetMinCount() {
		HashMap<Double,Double> classCounts = new HashMap<Double,Double>();
		classCounts.put(1.0, 10.0);
		classCounts.put(2.0, 15.0);
		classCounts.put(3.0, 20.0);
		classCounts.put(4.0, 28.0);
		
		Double result = CommonMethods.getMinCount(classCounts);
		
		assertEquals(new Double(1.0), result);	
	}
	
	@Test
	public void testEuclideanDistance() {
		ArrayList<Double> a = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> b = new ArrayList<Double>(Arrays.asList(10.0,10.0,11.0,11.0,11.0,12.0,12.0));
		
		double dist = CommonMethods.euclideanDistance(a, b);
		DecimalFormat df = new DecimalFormat("#.####");
		dist = Double.parseDouble(df.format(dist));
		
		assertEquals(new Double(19.2873), new Double(dist));
	}	
	
	@Test
	public void testManhattanDistance() {
		
		ArrayList<Double> a = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> b = new ArrayList<Double>(Arrays.asList(10.0,10.0,11.0,11.0,11.0,12.0,12.0));
		
		double dist = CommonMethods.manhattanDistance(a, b);
		
		assertEquals(new Double(44.0), new Double(dist));
	}
	
	@Test
	public void testHammingDistance() {
		ArrayList<Double> a = new ArrayList<Double>(Arrays.asList(1.0,1.0,1.0,1.0,1.0,1.0,1.0));
		ArrayList<Double> b = new ArrayList<Double>(Arrays.asList(1.0,0.0,0.0,1.0,0.0,0.0,1.0));
		
		double dist = CommonMethods.hammingDistance(a, b);
		
		assertEquals(new Double(4.0), new Double(dist));
	}

	@Test
	public void testCalcDistance() {
		
		ArrayList<Double> a = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,12.0,3.0,12.0));
		ArrayList<Double> b = new ArrayList<Double>(Arrays.asList(10.0,10.0,11.0,11.0,11.0,12.0,12.0));
		
		double eucdist = CommonMethods.euclideanDistance(a, b);
		double mandist = CommonMethods.manhattanDistance(a, b);
		double hamdist = CommonMethods.hammingDistance(a, b);
		
		double feucdist = CommonMethods.calcDistance(a, b, "euclidean");
		double fmandist = CommonMethods.calcDistance(a, b, "manhattan");
		double fhamdist = CommonMethods.calcDistance(a, b, "hamming");
		
		assertEquals(new Double(eucdist), new Double(feucdist));
		assertEquals(new Double(mandist), new Double(fmandist));
		assertEquals(new Double(hamdist), new Double(fhamdist));
	}
	
	@Test
	public void testIsDoubleVal() {
		String a = "1.0";
		String b = "1";
		String c = "one";
		
		assertEquals(true, CommonMethods.isDoubleVal(a));
		assertEquals(true, CommonMethods.isDoubleVal(b));
		assertEquals(false, CommonMethods.isDoubleVal(c));
	}
	
	@Test
	public void testIsNumericAtt() {
		ArrayList<String> col1 = new ArrayList<String>(Arrays.asList("1.0","5.0","a","1.0"));
		ArrayList<String> col2 = new ArrayList<String>(Arrays.asList("12.0","11.0","10.0hs","11.0"));
		ArrayList<String> col3 = new ArrayList<String>(Arrays.asList("3","7","11","5"));
		ArrayList<String> col4 = new ArrayList<String>(Arrays.asList("4.0","8.0","12.0","5.00"));
		
		assertEquals(false, CommonMethods.isNumericAtt(col1));
		assertEquals(false, CommonMethods.isNumericAtt(col2));
		assertEquals(true, CommonMethods.isNumericAtt(col3));
		assertEquals(true, CommonMethods.isNumericAtt(col4));
	}
	
	@Test
	public void testGetHeadings() {
		ArrayList<String> col1 = new ArrayList<String>(Arrays.asList("apple","orange","banana","pinapple"));
		ArrayList<String> col2 = new ArrayList<String>(Arrays.asList("12.0","11.0","10.0hs","11.0"));
		ArrayList<String> col3 = new ArrayList<String>(Arrays.asList("3","7","11","5"));
		ArrayList<String> col4 = new ArrayList<String>(Arrays.asList("4.0","8.0","12.0","5.00"));
		
		ArrayList<ArrayList<String>> colStruct = new ArrayList<ArrayList<String>>(Arrays.asList(col1,col2,col3,col4));
		
		HashMap<String,Integer> headingsT = new HashMap<String,Integer>();
		headingsT.put("apple", 0);
		headingsT.put("orange", 1);
		headingsT.put("banana", 2);
		headingsT.put("pinapple", 3);
		HashMap<String,Integer> headingsF = new HashMap<String,Integer>();
		headingsF.put("0", 0);
		headingsF.put("1", 1);
		headingsF.put("2", 2);
		headingsF.put("3", 3);
		
		HashMap<String,Integer> headings1 = CommonMethods.getHeadings(colStruct, true);
		HashMap<String,Integer> headings2 = CommonMethods.getHeadings(colStruct, false);
		
		assertEquals(headings1, headingsT);
		assertEquals(headings2, headingsF);
	}
	
	@Test
	public void testConvertAtt() {
		ArrayList<String> orig1 = new ArrayList<String>(Arrays.asList("apple","orange","banana","apple"));
		ArrayList<String> orig2 = new ArrayList<String>(Arrays.asList("apple","orange","banana","pinapple"));
		
		ArrayList<String> res1 = new ArrayList<String>(Arrays.asList("1.0","2.0","3.0","1.0"));
		ArrayList<String> res2 = new ArrayList<String>(Arrays.asList("1.0","2.0","3.0","4.0"));
		
		assertEquals(res1, CommonMethods.convertAtt(orig1));
		assertEquals(res2, CommonMethods.convertAtt(orig2));
	}
	
	@Test
	public void testRandomlyHalfSet() {
		ArrayList<Double> col1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0,2.0,3.0,4.0));
		ArrayList<Double> col2 = new ArrayList<Double>(Arrays.asList(12.0,11.0,10.0,11.0,10.0,11.0,12.0));
		ArrayList<Double> col3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0,5.0,6.0,7.0,8.0));
		ArrayList<Double> col4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0,5.0,6.0,7.0,8.0));
		
		ArrayList<ArrayList<Double>> colStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(col1,col2,col3,col4));
		
		Pair<ArrayList<ArrayList<Double>>,ArrayList<ArrayList<Double>>> output = CommonMethods.randomlyHalfSet(colStruct);
		
		ArrayList<ArrayList<Double>> a = output.getFirst();
		ArrayList<ArrayList<Double>> b = output.getSecond();
		
		assertEquals(colStruct.size(), (a.size() + b.size()));
		assertEquals(colStruct.containsAll(a), true);
		assertEquals(colStruct.containsAll(b), true);
	}
	
	@Test
	public void testConvertNonNumericAtts() {
		ArrayList<String> col1 = new ArrayList<String>(Arrays.asList("apple","orange","banana","pinapple"));
		ArrayList<String> col2 = new ArrayList<String>(Arrays.asList("12.0","11.0","10.0hs","11.0"));
		ArrayList<String> col3 = new ArrayList<String>(Arrays.asList("3","7","11","5"));
		ArrayList<String> col4 = new ArrayList<String>(Arrays.asList("4.0","8.0","12.0","5.00"));
		
		ArrayList<String> Bcol1 = new ArrayList<String>(Arrays.asList("1.0","2.0","3.0","4.0"));
		ArrayList<String> Bcol2 = new ArrayList<String>(Arrays.asList("1.0","2.0","3.0","2.0"));
		
		ArrayList<ArrayList<String>> colStruct = new ArrayList<ArrayList<String>>(Arrays.asList(col1,col2,col3,col4));
		ArrayList<ArrayList<String>> BcolStruct = new ArrayList<ArrayList<String>>(Arrays.asList(Bcol1,Bcol2,col3,col4));
		
		ArrayList<ArrayList<String>> rowStruct = CommonMethods.createRowStructure(colStruct);
		ArrayList<ArrayList<String>> BrowStruct = CommonMethods.createRowStructure(BcolStruct);
		
		assertEquals(CommonMethods.convertNonNumericAtts(rowStruct, false), BrowStruct);
	}
	
	@Test
	public void testReadDoubleStructure() {
		ArrayList<String> col1 = new ArrayList<String>(Arrays.asList("1.0","5.0","9.0","1.0"));
		ArrayList<String> col2 = new ArrayList<String>(Arrays.asList("12.0","11.0","10.0","11.0"));
		ArrayList<String> col3 = new ArrayList<String>(Arrays.asList("3.0","7.0","11.0","5.0"));
		ArrayList<String> col4 = new ArrayList<String>(Arrays.asList("4.0","8.0","12.0","5.0"));
		
		ArrayList<Double> Acol1 = new ArrayList<Double>(Arrays.asList(1.0,5.0,9.0,1.0));
		ArrayList<Double> Acol2 = new ArrayList<Double>(Arrays.asList(12.0,11.0,10.0,11.0));
		ArrayList<Double> Acol3 = new ArrayList<Double>(Arrays.asList(3.0,7.0,11.0,5.0));
		ArrayList<Double> Acol4 = new ArrayList<Double>(Arrays.asList(4.0,8.0,12.0,5.0));
		
		ArrayList<ArrayList<String>> colStruct = new ArrayList<ArrayList<String>>(Arrays.asList(col1,col2,col3,col4));
		ArrayList<ArrayList<Double>> AcolStruct = new ArrayList<ArrayList<Double>>(Arrays.asList(Acol1,Acol2,Acol3,Acol4));
		
		assertEquals(CommonMethods.readDoubleStructure(colStruct),AcolStruct);
	}
	
	
	@Test
	public void testDecodeToStringStructure() {
		
		ArrayList<String> row1 = new ArrayList<String>(Arrays.asList("1.0","5.0","9.0","1.0"));
		ArrayList<String> row2 = new ArrayList<String>(Arrays.asList("12.0","11.0","10.0","11.0"));
		ArrayList<String> row3 = new ArrayList<String>(Arrays.asList("3.0","7.0","11.0","5.0"));
		ArrayList<String> row4 = new ArrayList<String>(Arrays.asList("4.0","8.0","12.0","5.0"));
		
		ArrayList<ArrayList<String>> dataset = new ArrayList<ArrayList<String>>(Arrays.asList(row1,row2,row3,row4));
		String dataSetString = "";
		
		for(int i = 0; i < dataset.size() -1; i++){
			ArrayList<String> line = dataset.get(i);
			for(int j =0; j < line.size() -1; j++){
				String value = line.get(j);
				dataSetString += value+",";
			}
			dataSetString += line.get(line.size()-1)+"\r\n"; //end of line
		}
		ArrayList<String> line = dataset.get(dataset.size()-1);
		for(int j =0; j < line.size() -1; j++){
			String value = line.get(j);
			dataSetString += value+",";
		}
		dataSetString += line.get(line.size()-1); //end of file	
		
		byte [] array = dataSetString.getBytes();
		String encodedFile = Base64.getEncoder().encodeToString(array);
		ArrayList<ArrayList<String>> newDataset = CommonMethods.decodeToStringStructure(encodedFile);
		
		assertEquals(dataset, newDataset);	
	}
	
	@Test
	public void testEqualsDouble() {
		Double a = 1.0;
		Double b = 7.0;
		Double c = 1.1;
		Double d = 1.0;
		
		assertEquals(CommonMethods.equalsDouble(a,b), false);
		assertEquals(CommonMethods.equalsDouble(a,c), false);
		assertEquals(CommonMethods.equalsDouble(a,d), true);
		
	}
}

package project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;

import project.model.DataSetConfig;
import project.model.FormulaRunConfig;
import project.model.KNNRunConfig;
import project.model.RunConfig;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { PredictiveApp.class })
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class PredictiveRestTestClient {

  public static final String REST_SERVICE_URI = "http://localhost:8080/PredictiveToolkit/api";

  @Test
  public void testStartUp() throws IOException {
    final ClassLoader classLoader = getClass().getClassLoader();
    final File file = new File(classLoader.getResource("CarDataNumerical.csv").getFile());
    System.out.println(file.getAbsolutePath());

    testCreateDataSet(file.getAbsolutePath(), 1, "Cars");

    testCreateKNN(1);
    testCreateNB(2);
    testCreateNC(3);
    testCreateDT(4);

    testListAllResults();
    testDeleteAllResults();
    testListAllResults_ALL_DELETED();
  }

  /* GET */
  @SuppressWarnings("unchecked")
  private void testListAllResults() {
    final RestTemplate restTemplate = new RestTemplate();
    final List<LinkedHashMap<String, Object>> resultsMap = restTemplate.getForObject(REST_SERVICE_URI + "/results/",
        List.class);

    assertNotNull(resultsMap);
    assertEquals(4, resultsMap.size());
    assertEquals(1, resultsMap.get(0).get("id"));
    assertEquals(2, resultsMap.get(1).get("id"));
    assertEquals(3, resultsMap.get(2).get("id"));
    assertEquals(4, resultsMap.get(3).get("id"));
  }

  private void testListAllResults_ALL_DELETED() {
    final RestTemplate restTemplate = new RestTemplate();
    try {
      restTemplate.getForObject(REST_SERVICE_URI + "/results/", List.class);
      fail("Should have thrown exception for 404.");
    }
    catch (final HttpClientErrorException e) {

    }
  }

  /* DELETE */
  private void testDeleteAllResults() {
    final RestTemplate restTemplate = new RestTemplate();
    restTemplate.delete(REST_SERVICE_URI + "/results/");
  }

  /* POST */
  private void testCreateKNN(final int expectedId) {
    final RestTemplate restTemplate = new RestTemplate();
    final KNNRunConfig config = new KNNRunConfig(1, new int[] { 0, 1, 2, 3, 4, 5 }, 6, null, "euclidean", 5);
    final ResponseEntity<String> response = restTemplate.postForEntity(REST_SERVICE_URI + "/KNNEngine/", config,
        String.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertEquals("/PredictiveToolkit/api/results/" + expectedId, response.getHeaders().getLocation().getPath());
  }

  /* POST */
  private void testCreateNB(final int expectedId) {
    final RestTemplate restTemplate = new RestTemplate();
    final RunConfig config = new RunConfig(1, new int[] { 0, 1, 2, 3, 4, 5 }, 6, null);
    final ResponseEntity<String> response = restTemplate.postForEntity(REST_SERVICE_URI + "/NBEngine/", config,
        String.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertEquals("/PredictiveToolkit/api/results/" + expectedId, response.getHeaders().getLocation().getPath());
  }

  /* POST */
  private void testCreateNC(final int expectedId) {
    final RestTemplate restTemplate = new RestTemplate();
    final FormulaRunConfig config = new FormulaRunConfig(1, new int[] { 0, 1, 2, 3, 4, 5 }, 6, null, "euclidean");
    final ResponseEntity<String> response = restTemplate.postForEntity(REST_SERVICE_URI + "/NCEngine/", config,
        String.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertEquals("/PredictiveToolkit/api/results/" + expectedId, response.getHeaders().getLocation().getPath());
  }

  /* POST */
  private void testCreateDT(final int expectedId) {
    final RestTemplate restTemplate = new RestTemplate();
    final FormulaRunConfig config = new FormulaRunConfig(1, new int[] { 0, 1, 2, 3, 4, 5 }, 6, null, "GainRatio");
    final ResponseEntity<String> response = restTemplate.postForEntity(REST_SERVICE_URI + "/DTEngine/", config,
        String.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertEquals("/PredictiveToolkit/api/results/" + expectedId, response.getHeaders().getLocation().getPath());
  }

  /* POST */
  private void testCreateDataSet(final String path, final int id, final String name) throws IOException {
    final RestTemplate restTemplate = new RestTemplate();
    final byte[] array = Files.readAllBytes(new File(path).toPath());
    final String encodedFile = Base64.getEncoder().encodeToString(array);
    final DataSetConfig config = new DataSetConfig(true, encodedFile, null, true, name);

    final URI uri = restTemplate.postForLocation(REST_SERVICE_URI + "/datasets/", config, DataSetConfig.class);
    final ResponseEntity<String> response = restTemplate.postForEntity(REST_SERVICE_URI + "/datasets/", config,
        String.class);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertEquals("/PredictiveToolkit/api/datasets/2", response.getHeaders().getLocation().getPath());
  }

  /* DELETE */
  private void deleteDataset() {
    System.out.println("Testing delete Dataset API----------");
    final RestTemplate restTemplate = new RestTemplate();
    restTemplate.delete(REST_SERVICE_URI + "/datasets/3");
  }
}

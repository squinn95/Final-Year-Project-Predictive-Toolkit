package project.algorithm;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import project.util.*;

import java.text.DecimalFormat;

public class CommonMethods{
		
	protected static <T> ArrayList<ArrayList<T>> createColumnStructure(ArrayList<ArrayList<T>> rowInput){
		//for each row, add element at each index to arraylist at that index in columns
		ArrayList<ArrayList<T>> columns = new ArrayList<ArrayList<T>>();
		for(int i = 0; i < rowInput.get(0).size(); i++){ //for each column
			ArrayList<T> current = new ArrayList<T>();
			for(ArrayList<T> row: rowInput){
				current.add(row.get(i));
			}
			columns.add(current);
		}
		return columns;
	}
		
	protected static <T> ArrayList<ArrayList<T>> createRowStructure(ArrayList<ArrayList<T>> columnInput){
		//for each row, add element at each index to arraylist at that index in columns
		ArrayList<ArrayList<T>> rows = new ArrayList<ArrayList<T>>();
		for(int i =0; i < columnInput.get(0).size(); i++ ){ //for each row
			ArrayList<T> current = new ArrayList<T>();
			for (ArrayList<T> column: columnInput) {
				current.add(column.get(i)); 
			}
			rows.add(current);
		}
		return rows;
	}
	
	protected static ArrayList<ArrayList<Double>> trimColumns(ArrayList<ArrayList<Double>> columns, int [] columnsToUse, int predictionColumn){
		ArrayList<ArrayList<Double>> newColumns = new ArrayList<ArrayList<Double>>();
		for(int a: columnsToUse){
			newColumns.add(columns.get(a));
		} // adds only the columns needed for prediction to newColumns
		newColumns.add(columns.get(predictionColumn)); //add predictionColumn last
		return newColumns;
	}
	
	protected static ArrayList<ArrayList<Double>> normaliseDataset(ArrayList<ArrayList<Double>> dataset, ArrayList<ArrayList<Double>> columns) { // all values in the range 0-1 to stop skewing by attributes such as age
		DecimalFormat df = new DecimalFormat("#.####");
		ArrayList<ArrayList<Double>> newDataset = new ArrayList<ArrayList<Double>>();
		int size = columns.size() -1; //-1 because we dont want to normalise prediction column
		double [] maxValues = new double [size];
		double [] minValues = new double [size]; // these will hold max and min values for each column
		for (int i = 0; i < size; i++) {
			maxValues[i] = Collections.max(columns.get(i));
			minValues[i] = Collections.min(columns.get(i));
		}
		
		Iterator<ArrayList<Double>> iter = dataset.iterator();
		while (iter.hasNext()) { // loop through rows
			ArrayList<Double> current = iter.next(); // current row
			ArrayList<Double> newRow = new ArrayList<Double>();
			for (int i = 0; i < size; i++) { // loop through  rows to be normalised
				double oldValue = current.get(i);
				double normValue = Double.parseDouble(df.format((oldValue - minValues[i])/(maxValues[i]- minValues[i]))); // normalisation formula
				newRow.add(normValue);
			}
			newRow.add(current.get(current.size()-1)); //add last element the prediction column
			newDataset.add(newRow);
		}
		return newDataset;
	}
	
	protected static ArrayList<ArrayList<Double>> classifyDataset(ArrayList<ArrayList<Double>> dataset, int [] splitPoints) { // this sets up classes in training set, replacing continuous value with class
		if((splitPoints != null) && (splitPoints.length > 0)){
			ArrayList<ArrayList<Double>> newDataset = new ArrayList<ArrayList<Double>>(dataset);
			Iterator<ArrayList<Double>> iter4 = newDataset.iterator();
			while (iter4.hasNext()) { // loop through rows
				ArrayList<Double> current = iter4.next(); // current row
				Double value = current.get(current.size() -1); //last row is predictionColumn since trim
				int classCount = 1;
				boolean assigned = false;
				loop:
				for(int i = 0; i < splitPoints.length; i++){
					if(value < splitPoints[i]){
						//class = classCount
						current.remove(current.size() -1); //replace last element with class
						current.add(new Double(classCount));
						assigned = true;
						break loop;
					}
					classCount++;
				}
				if(assigned == false){
					//class = classCount
					current.remove(current.size() -1); 
					current.add(new Double(classCount));
					assigned = true;
				}
				//System.out.println(value + ": " + classCount );
				//System.out.println(current);
			}
			return newDataset;
		}
		else{
			return dataset;
		}
	}
	
	static boolean equalsDouble(Double a, Double b){
		return (Double.doubleToLongBits(a) == Double.doubleToLongBits(b));
	}
	
	static int getColumnCount(ArrayList<Double> list, Double value){
		int count = 0;
		for(Double d: list){
				if(CommonMethods.equalsDouble(d,value)){
					count++;
				}
		}
		return count;
	}
	
	static HashMap<Double,ArrayList<ArrayList<Double>>> getIndexColumnStructuresMap(ArrayList<ArrayList<Double>> trainSet, HashMap<Double,ArrayList<Integer>> indexLocationMap){
		HashMap<Double,ArrayList<ArrayList<Double>>> indexColumnStructures = new HashMap<Double,ArrayList<ArrayList<Double>>>();
		for(Double value: indexLocationMap.keySet()){ //for each value associated with this attribute
			ArrayList<ArrayList<Double>> currentValueRowStructure = new ArrayList<ArrayList<Double>>();
			for(Integer index: indexLocationMap.get(value)){ //for each row number associated with this value
				currentValueRowStructure.add(trainSet.get(index));
			}
			ArrayList<ArrayList<Double>> currentValueColumnStructure = CommonMethods.createColumnStructure(currentValueRowStructure); //convert to column format
			indexColumnStructures.put(value,currentValueColumnStructure); //put class, column structure in result
		}
		return indexColumnStructures;
	}
	
	static HashMap<Double,ArrayList<Integer>> getColumnValueLocationMap(ArrayList<ArrayList<Double>> trainColumns, int index){
		ArrayList<Double> targetColumn = trainColumns.get(index); //last column
		
		HashMap<Double,ArrayList<Integer>> indexMap = new HashMap<Double,ArrayList<Integer>>();
		//ArrayList<Double> result = new ArrayList<Double>();
		
		for(int i=0; i < targetColumn.size(); i++){
			Double value = targetColumn.get(i);
			if(indexMap.containsKey(value)){
					ArrayList<Integer> current = indexMap.get(value);
					current.add(i); //add this index to the list of indexes corresponding to this class value
					indexMap.put(value, current);
			}
			else{
				ArrayList<Integer> current = new ArrayList<Integer>();
				current.add(i);
				indexMap.put(value, current);
			}
		}
		
		return indexMap;
	}
	
	static Double getMaxCount(HashMap<Double,Double> classCounts){
		//create tree map with comparitor which sorts by value instead of key
		TreeSet<Map.Entry<Double, Double>> entriesSet = new TreeSet<>(new Comparator<Map.Entry<Double, Double>>(){
           @Override 
			public int compare(Map.Entry<Double, Double> x, Map.Entry<Double, Double> y) {
				return x.getValue().compareTo(y.getValue());
			}
        });
        entriesSet.addAll(classCounts.entrySet());
		return entriesSet.last().getKey();
	}
	
	static Double getMinCount(HashMap<Double,Double> classCounts){
		//create tree map with comparitor which sorts by value instead of key
		TreeSet<Map.Entry<Double, Double>> entriesSet = new TreeSet<>(new Comparator<Map.Entry<Double, Double>>(){
           @Override 
			public int compare(Map.Entry<Double, Double> x, Map.Entry<Double, Double> y) {
				return x.getValue().compareTo(y.getValue());
			}
        });
        entriesSet.addAll(classCounts.entrySet());
		return entriesSet.first().getKey();
	}
	
	static double euclideanDistance(ArrayList<Double> a, ArrayList<Double> b){ 
		double total = 0;
		for(int i = 0; i < a.size() - 1; i++){ //-1 added as you are not taking pred coulmun into calculation
			double difference = (a.get(i) - b.get(i));
			total += (difference * difference); //replace 1 with weighting scheme
		}
		return Math.sqrt(total);
	}
	
	static double manhattanDistance(ArrayList<Double> a, ArrayList<Double> b){ 
		double total = 0;
		for(int i = 0; i < a.size() - 1; i++){ //-1 added as you are not taking pred coulmun into calculation
			double difference = (a.get(i) - b.get(i));
			total += Math.abs(difference); 
		}
		return total;
	}
	
	static double calcDistance(ArrayList<Double> a, ArrayList<Double> b, String formula){
			if(formula.equals("manhattan")){
				return manhattanDistance(a, b);
			}
			else if(formula.equals("hamming")){
				return hammingDistance(a,b);
			}
			else{	
				return euclideanDistance(a, b);
			}
	}
	
	public static int hammingDistance(ArrayList<Double> a, ArrayList<Double> b){
		int totalDif = 0;
		for(int i = 0; i < a.size() -1; i++){//-1 added as you are not taking pred coulmun into calculation
			if(!equalsDouble(a.get(i),b.get(i))){
				totalDif++;
			}
		}
		return totalDif;
	}
	
	public static ArrayList<ArrayList<String>> decodeToStringStructure(String encodedDataSet){
		byte[] decodedArray = Base64.getDecoder().decode(encodedDataSet);
		
		String file = new String(decodedArray);
		
		StringTokenizer st = new StringTokenizer(file,"\r\n"); 

		ArrayList<ArrayList<String>> dataset = new ArrayList<ArrayList<String>>();
		
		while (st.hasMoreTokens()) {
		   String line = st.nextToken();
		   String [] values = line.split(",");
		   ArrayList<String> row = new ArrayList<String>(Arrays.asList(values));
		   dataset.add(row);
		   //System.out.println("#" + row);
		}
		
		return dataset;
	}	
	
	public static ArrayList<ArrayList<Double>> readDoubleStructure(ArrayList<ArrayList<String>> stringDataset){

		ArrayList<ArrayList<Double>> dataset = new ArrayList<ArrayList<Double>>();
		
		for(int i =0;i < stringDataset.size(); i++){
			ArrayList<String> currentLine = stringDataset.get(i);
			ArrayList<Double> newLine = new ArrayList<Double>();
			for(String current: currentLine){
				newLine.add(Double.parseDouble(current));
			}
			dataset.add(newLine);
		}
		
		return dataset;
	}
	
	public static ArrayList<ArrayList<String>> convertNonNumericAtts(ArrayList<ArrayList<String>> stringTrainSet, boolean headings){
		ArrayList<ArrayList<String>> rowStruct = stringTrainSet;
		if(headings){
			rowStruct.remove(0);
		}
		ArrayList<ArrayList<String>> colStruct = createColumnStructure(rowStruct);
		for(int i =0; i < colStruct.size(); i++){
			if(!isNumericAtt(colStruct.get(i))){
				colStruct.set(i, convertAtt(colStruct.get(i)));
			}
		}		
		ArrayList<ArrayList<String>> result = createRowStructure(colStruct);		
		return result;
	}
	
	public static boolean isNumericAtt(ArrayList<String> values){
		boolean result = true;
		for(String a: values){
			if(!isDoubleVal(a)){
				result = false;
				break;
			}
		}
		return result;
	}
	
	@SuppressWarnings("finally")
	public static boolean isDoubleVal(String a){
		boolean result = true;
		try{
		  Double.parseDouble(a);
		}
		catch(NumberFormatException e)
		{
		  result = false;
		}
		finally{
			return result;
		}
	}
	
	public static ArrayList<String> convertAtt(ArrayList<String> inputColAtt){
		HashMap<String, String> mappings = new HashMap<String, String>();
		ArrayList<String> newCol = new ArrayList<String>();
		double count = 1.0;
		for(int i = 0; i < inputColAtt.size(); i++){
			String current = inputColAtt.get(i);
			if(mappings.containsKey(current)){
				newCol.add(mappings.get(current));
			}
			else{
				String replacement = count + "";
				count++;
				mappings.put(current,replacement);
				newCol.add(replacement);
			}
		}
		return newCol;
	}
	
	public static HashMap<String,Integer> getHeadings(ArrayList<ArrayList<String>> dataset, boolean headings){

		HashMap<String,Integer> result = new HashMap<String,Integer>();
		
		ArrayList<String> firstLine = dataset.get(0);
		
		if(headings){
			for(int i = 0; i < firstLine.size(); i++){
				result.put(firstLine.get(i),i);
			}
		}
		else{
			for(int i = 0; i < firstLine.size(); i++){
				result.put(i+"",i);
			}
		}
		return result;
	}
	
	public static Pair<ArrayList<ArrayList<Double>>,ArrayList<ArrayList<Double>>> randomlyHalfSet(ArrayList<ArrayList<Double>> inputSet){ //splits it roughly in half
		ArrayList<ArrayList<Double>> trainingSet = new ArrayList<ArrayList<Double>>();
		ArrayList<ArrayList<Double>> validationSet = new ArrayList<ArrayList<Double>>();
		Iterator<ArrayList<Double>> iter5 = inputSet.iterator(); // splits into two sets
        int rnd;
		while (iter5.hasNext()) { // loop through rows
			rnd = ThreadLocalRandom.current().nextInt(1, 11);
			if (rnd <= 5)
				trainingSet.add(iter5.next()); 
			else
				validationSet.add(iter5.next());
		}
		Pair<ArrayList<ArrayList<Double>>,ArrayList<ArrayList<Double>>> output = new Pair(trainingSet, validationSet);
		return output;
	}
	
}

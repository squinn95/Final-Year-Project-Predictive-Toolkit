package project.algorithm;

import java.util.*;
import project.model.*;
import project.util.*;
import java.util.concurrent.ThreadLocalRandom;

//Rocchio classifier
public class NearestCentroid{
	
	//private static void predictClassNearestCentroid(boolean partitionTrainSet, String trainSetPath, String validationSetPath, boolean headings, int [] columnsToUse, int predictionColumn, int [] splitPoints, String formula ) {
	public static RunResult predictClassNearestCentroid(DataSet data, int [] columnsToUse, int predictionColumn, int [] splitPoints, String formula ) {	
	
		ArrayList<ArrayList<Double>> trainSet = data.getTrainSet();
		ArrayList<ArrayList<Double>> validationSet = data.getValidationSet();
		
		//create column structure
		ArrayList<ArrayList<Double>> trainColumns = CommonMethods.createColumnStructure(trainSet);
		ArrayList<ArrayList<Double>> validationColumns = CommonMethods.createColumnStructure(validationSet);
		
		//trim columns which wont be used
		trainColumns = CommonMethods.trimColumns(trainColumns, columnsToUse, predictionColumn);
		validationColumns = CommonMethods.trimColumns(validationColumns, columnsToUse, predictionColumn);
		
		//convert trimmed columns back to row structure
		trainSet = CommonMethods.createRowStructure(trainColumns);
		validationSet = CommonMethods.createRowStructure(validationColumns);
		
		if(!formula.equals("hamming")){
			//normalise set
			trainSet = CommonMethods.normaliseDataset(trainSet, trainColumns);
			validationSet = CommonMethods.normaliseDataset(validationSet, validationColumns);
		}
		
		//split classification column into sets if needed, for continuous variables
		trainSet = CommonMethods.classifyDataset(trainSet, splitPoints);
		validationSet = CommonMethods.classifyDataset(validationSet, splitPoints);
		
		trainColumns = CommonMethods.createColumnStructure(trainSet);
		validationColumns = CommonMethods.createColumnStructure(validationSet);
		
		HashMap<Double, ArrayList<Double>> classCentroids;
		
		if(formula.equals("hamming")){
			classCentroids = getClassHammingCentroids(trainColumns);
		}
		else{
			classCentroids = getClassCentroids(trainColumns);
		}
		
		Iterator<ArrayList<Double>> iter6 = validationSet.iterator();
		
		double rightCount = 0;
		double g = 0;
		while (iter6.hasNext()) { // classify validation set one by one using knn and add to resultsMap
		
			ArrayList<Double> current = iter6.next(); // current validation row
			
			HashMap<Double,Double> centroidDistances = new HashMap<Double,Double>();
			for(Double currentClass: classCentroids.keySet()){
				ArrayList<Double> currentCentroid = classCentroids.get(currentClass);
				double dist = CommonMethods.calcDistance(current,currentCentroid,formula);
				centroidDistances.put(currentClass,dist);
			}			
			Double classValue = CommonMethods.getMinCount(centroidDistances);
			if(CommonMethods.equalsDouble(current.get(current.size()-1),classValue))
				rightCount++;
			g++;
		}		
		return new RunResult((int)g, (int)rightCount, AlgorithmType.NC);		
	}
	
	public static HashMap<Double, ArrayList<Double>> getClassCentroids(ArrayList<ArrayList<Double>> trainColumns){
		HashMap<Double,ArrayList<Integer>> classLocations = CommonMethods.getColumnValueLocationMap(trainColumns, trainColumns.size()-1);
		
		HashMap<Double,ArrayList<ArrayList<Double>>> classColumnStructures = CommonMethods.getIndexColumnStructuresMap(CommonMethods.createRowStructure(trainColumns), classLocations);
		
		HashMap<Double, ArrayList<Double>> classCentroids = new HashMap<Double, ArrayList<Double>>();
		
		for(Double current: classColumnStructures.keySet()){ //for each class
			ArrayList<ArrayList<Double>> currentClassColumns = classColumnStructures.get(current);
			ArrayList<Double> currentCentroid = new ArrayList<Double>();
			for(int i =0; i < currentClassColumns.size()-1; i++){ //for each row of this class except pred column
				ArrayList<Double> currentAttribute = currentClassColumns.get(i);
				Double avg = getAvg(currentAttribute); //do this method 
				currentCentroid.add(avg);
			}
			currentCentroid.add(current);
			classCentroids.put(current,currentCentroid);
		}
		return classCentroids;
	}
	
	public static HashMap<Double, ArrayList<Double>> getClassHammingCentroids(ArrayList<ArrayList<Double>> trainColumns){
		HashMap<Double,ArrayList<Integer>> classLocations = CommonMethods.getColumnValueLocationMap(trainColumns, trainColumns.size()-1);
		
		HashMap<Double,ArrayList<ArrayList<Double>>> classColumnStructures = CommonMethods.getIndexColumnStructuresMap(CommonMethods.createRowStructure(trainColumns), classLocations);
		
		HashMap<Double, ArrayList<Double>> classCentroids = new HashMap<Double, ArrayList<Double>>();
		
		for(Double current: classColumnStructures.keySet()){ //for each class
			ArrayList<ArrayList<Double>> currentClassColumns = classColumnStructures.get(current);
			ArrayList<Double> currentCentroid = new ArrayList<Double>();
			for(int i =0; i < currentClassColumns.size()-1; i++){ //for each attribute of this class except pred column
				ArrayList<Double> currentAttribute = currentClassColumns.get(i); //get most common value in this and add to current centroid
				Double val = getMostCommonVal(currentAttribute); 
				currentCentroid.add(val);
			}
			currentCentroid.add(current);
			classCentroids.put(current,currentCentroid);
		}
		return classCentroids;
	}
	
	public static Double getMostCommonVal(ArrayList<Double> input){
		HashMap<Double, Double> counts = new HashMap<>();
		for(int i =0; i < input.size(); i++){
			Double val = input.get(i);
			if(counts.containsKey(val)){
				Double currCount = counts.get(val);
				currCount++;
				counts.put(val, currCount);
			}
			else{
				counts.put(val, 1.0);
			}
		}
		Double max = getBestClass(counts);
		return max;
	}
	
	public static Double getBestClass(HashMap<Double, Double> counts){
		TreeSet<Map.Entry<Double, Double>> entriesSet = new TreeSet<>(new Comparator<Map.Entry<Double, Double>>(){
	           @Override 
				public int compare(Map.Entry<Double, Double> x, Map.Entry<Double, Double> y) {
					return x.getValue().compareTo(y.getValue());
				}
	     });
	     entriesSet.addAll(counts.entrySet());
	     Double max = entriesSet.last().getValue();
	     ArrayList<Double> maxClasses = new ArrayList<Double>();
	     for(Double a: counts.keySet()){
	    	 if(CommonMethods.equalsDouble(max, counts.get(a))){
	    		 maxClasses.add(a);
	    	 }
	     }
	     int randomIndex = ThreadLocalRandom.current().nextInt(0, maxClasses.size());
	     return maxClasses.get(randomIndex);
	}
	
	public static double getAvg(ArrayList<Double> currentAttribute){
		double size = (double) currentAttribute.size();
		double total = 0.0;
		for(Double x: currentAttribute){
			total += x;
		}
		return (total/size);
	}
}
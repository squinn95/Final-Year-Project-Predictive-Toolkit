package project.algorithm;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import project.model.*;
import project.util.*;

public class KNN{
	
	public static RunResult predictClassKNN(DataSet data, int [] columnsToUse, int predictionColumn, int [] splitPoints, int k, String formula ) {
		
		ArrayList<ArrayList<Double>> trainSet = data.getTrainSet();
		ArrayList<ArrayList<Double>> validationSet = data.getValidationSet();
		
		//create column structure
		ArrayList<ArrayList<Double>> trainColumns = CommonMethods.createColumnStructure(trainSet);
		ArrayList<ArrayList<Double>> validationColumns = CommonMethods.createColumnStructure(validationSet);
		
		//trim columns which wont be used
		trainColumns = CommonMethods.trimColumns(trainColumns, columnsToUse, predictionColumn);
		validationColumns = CommonMethods.trimColumns(validationColumns, columnsToUse, predictionColumn);
		
		//convert trimmed columns back to row structure
		trainSet = CommonMethods.createRowStructure(trainColumns);
		validationSet = CommonMethods.createRowStructure(validationColumns);
		
		if(!formula.equals("hamming")){
			//normalise set
			trainSet = CommonMethods.normaliseDataset(trainSet, trainColumns);
			validationSet = CommonMethods.normaliseDataset(validationSet, validationColumns);
		}
		
		//split classification column into sets if needed, for continuous variables
		trainSet = CommonMethods.classifyDataset(trainSet, splitPoints);
		validationSet = CommonMethods.classifyDataset(validationSet, splitPoints);
		
		Iterator<ArrayList<Double>> iter6 = validationSet.iterator();
		
		double rightCount = 0;
		int g = 0;
		while (iter6.hasNext()) { // classify validation set one by one using knn and add to resultsMap
		
			int currentK = k;
			ArrayList<Double> current = iter6.next(); // current validation row
			
			TreeMap<Double,ArrayList<Double>> distanceMap = genDistanceMap(current, trainSet, formula);
			
			TreeMap<Double,ArrayList<Double>> neighbourMap = getKClosest(distanceMap, currentK);
			
			HashMap<Double,Double> classCounts = getClassCounts(neighbourMap);
			
			while(!isOneMax(classCounts)){ //in event of tie reduce k by 1 and re-run
				currentK--;
				neighbourMap = getKClosest(neighbourMap, currentK);
				classCounts = getClassCounts(neighbourMap);
			}
			
			Double classValue = CommonMethods.getMaxCount(classCounts);
			
			if(CommonMethods.equalsDouble(current.get(current.size()-1),classValue))
				rightCount++;

			g++;
			
		}
		
		return new RunResult((int)g, (int)rightCount, AlgorithmType.KNN);
	}
	
	private static HashMap<Double, Double> getClassCounts(TreeMap<Double,ArrayList<Double>> neighbourMap){
		HashMap<Double, Double> classCounts = new HashMap<Double, Double>();
		for(Double x: neighbourMap.keySet()){ //distances
			ArrayList<Double> current = neighbourMap.get(x); // class values associated with distance x
			for(Double a: current){ //for each class value associated with current dist
				if(classCounts.containsKey(a)){
					Double count = classCounts.get(a);
					count++;
					classCounts.put(a, count);
				}
				else{
					classCounts.put(a, 1.0);
				}
			}
		}
		return classCounts;
	}
	
	private static ArrayList<Double> getNRandomListDoubles(ArrayList<Double> inputList, int n){
		ArrayList<Double> input = new ArrayList<Double>(inputList); //because arraylists passed by reference
		ArrayList<Double> output = new ArrayList<Double>();
		for(int i = 0; i < n; i++){
			int rnd = ThreadLocalRandom.current().nextInt(0, input.size());
			output.add(input.get(rnd));
			input.remove(rnd);
		}
		return output;
	}
	
	private static TreeMap<Double,ArrayList<Double>> getKClosest(TreeMap<Double,ArrayList<Double>> input, int k){
		TreeMap<Double,ArrayList<Double>> distanceMap = new TreeMap<Double,ArrayList<Double>>(input); //because of pass by reference
		TreeMap<Double,ArrayList<Double>> neighbourMap = new TreeMap<Double,ArrayList<Double>>();
		int j = 0;
		while (j < k) { // k nearest neighbours
			Map.Entry<Double,ArrayList<Double>> a = distanceMap.pollFirstEntry(); // returns and removes smallest key entry in treemap - closest neighbour    (Store these in structure, method to get dominant one)
			int q = a.getValue().size();
					
			if((q + j) > k){
				int n = k - j; //choose n from q;
				ArrayList<Double> newA = getNRandomListDoubles(a.getValue(), n);
				neighbourMap.put(a.getKey(),newA);
				j = j + n;
			}
			else{
				neighbourMap.put(a.getKey(),a.getValue());
				j = j + q;
			}
		}
		return neighbourMap;
	}
	
	private static TreeMap<Double,ArrayList<Double>> genDistanceMap(ArrayList<Double> valRow, ArrayList<ArrayList<Double>> trainSet, String formula) {
		TreeMap<Double,ArrayList<Double>> distanceMap = new TreeMap<Double,ArrayList<Double>>(); // this will hold (dist, classes) pairs. TreeMap keeps them in sorted order - can use pollFirstEntry
		Iterator<ArrayList<Double>> iter7 = trainSet.iterator(); // calculate distance from this to each row in training set
		while (iter7.hasNext()) {
			ArrayList<Double> trainRow = iter7.next();
				
			double dist = CommonMethods.calcDistance(valRow, trainRow, formula);
			if(distanceMap.containsKey(dist)){
				ArrayList<Double> t = distanceMap.get(dist);
				t.add(trainRow.get(trainRow.size() -1));
				distanceMap.put(dist, t);
			}
			else{
				ArrayList<Double> b = new ArrayList<Double>();
				b.add(trainRow.get(trainRow.size() -1));
				distanceMap.put(dist, b); //  last index holds class value of training set
			}
		}
		return distanceMap;
	}
	
	private static boolean isOneMax(HashMap<Double,Double> classCounts){
		//sort 
		//if next index the same as first then there is at least two max therefore return false
		if(classCounts.keySet().size() == 1){
				return true;
		}
		else{
			ArrayList<Double> a = new ArrayList<Double>();
			for(Double x: classCounts.keySet())
				a.add(classCounts.get(x));
			Collections.sort(a);
			Collections.reverse(a); //now in desc order
			if(a.get(0).equals(a.get(1))){
				return false;
			}
			else{
				return true;
			}
		}
	}
}
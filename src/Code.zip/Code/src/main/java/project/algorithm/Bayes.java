package project.algorithm;

import java.util.*;
import project.model.*;
import project.util.*;

public class Bayes{
	
	public static RunResult predictClassBayes(DataSet data, int [] columnsToUse, int predictionColumn, int [] splitPoints) {
		
		ArrayList<ArrayList<Double>> trainSet = data.getTrainSet();
		ArrayList<ArrayList<Double>> validationSet = data.getValidationSet();
		
		//create column structure
		ArrayList<ArrayList<Double>> trainColumns = CommonMethods.createColumnStructure(trainSet);
		ArrayList<ArrayList<Double>> validationColumns = CommonMethods.createColumnStructure(validationSet);
		
		//trim columns which wont be used
		trainColumns = CommonMethods.trimColumns(trainColumns, columnsToUse, predictionColumn);
		validationColumns = CommonMethods.trimColumns(validationColumns, columnsToUse, predictionColumn);
		
		//convert trimmed columns back to row structure
		trainSet = CommonMethods.createRowStructure(trainColumns);
		validationSet = CommonMethods.createRowStructure(validationColumns);
		
		//split classification column into sets if needed, for continuous variables
		trainSet = CommonMethods.classifyDataset(trainSet, splitPoints);
		validationSet = CommonMethods.classifyDataset(validationSet, splitPoints);
		
		trainColumns = CommonMethods.createColumnStructure(trainSet);
		validationColumns = CommonMethods.createColumnStructure(validationSet);
		
		HashMap<Double,ArrayList<Integer>> classIndexMap = CommonMethods.getColumnValueLocationMap(trainColumns, trainColumns.size()-1);
		
		HashMap<Double,ArrayList<ArrayList<Double>>> classColumnStructuresMap = CommonMethods.getIndexColumnStructuresMap(trainSet, classIndexMap);
		
		double totalSize = (double)trainSet.size();
		
		double rightCount = 0;
		int g = 0;
		Iterator<ArrayList<Double>> iter6 = validationSet.iterator();
		
		while (iter6.hasNext()) { // classify validation set one by one
		
			ArrayList<Double> currentRow = iter6.next(); // current validation row
			
			HashMap<Double,Double> classProbs = new HashMap<Double,Double>();
			
			for(Double currentClass: classColumnStructuresMap.keySet()){ //for each class
				ArrayList<ArrayList<Double>> classColumnSet = classColumnStructuresMap.get(currentClass);
				double classSize = (double)classColumnSet.get(0).size();
				
				double prob = (classSize/totalSize); //prior prob
				
				for(int i = 0; i < currentRow.size()-1; i++){ //each conditional prob
					Double compValue = currentRow.get(i);
					ArrayList<Double> classDimensionColumn = classColumnSet.get(i);
					double count = (double)CommonMethods.getColumnCount(classDimensionColumn, compValue);
					double conditionalProb = (count/classSize);
					prob *= conditionalProb;
				}

				classProbs.put(currentClass, prob);
			}
			
			Double classValue = CommonMethods.getMaxCount(classProbs);
			if(CommonMethods.equalsDouble(currentRow.get(currentRow.size()-1),classValue))
				rightCount++;

			g++;
		}
		
		return new RunResult((int)g, (int)rightCount, AlgorithmType.NB);
	
	}	

}
package project.model;
import java.util.*;

public class DataSet{
	private ArrayList<ArrayList<Double>> trainSet;
	private ArrayList<ArrayList<Double>> validationSet;
	private HashMap<String,Integer> headingsMap;
	private int id;
	private String name;
	
	public DataSet(ArrayList<ArrayList<Double>> trainSet, ArrayList<ArrayList<Double>> validationSet, int id, String name, HashMap<String, Integer> headingsMap){
		this.trainSet = trainSet;
		this.validationSet = validationSet;
		this.id = id;
		this.name = name;
		this.headingsMap = headingsMap;
	}
	
	public ArrayList<ArrayList<Double>> getTrainSet(){
		return trainSet;
	}
	
	public ArrayList<ArrayList<Double>> getValidationSet(){
		return validationSet;
	}
	
	public int getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public HashMap<String,Integer> getHeadingsMap(){
		return headingsMap;
	}
}
package project.model;

public class KNNRunConfig extends FormulaRunConfig{ //KNN
	private int k;
	
	public KNNRunConfig(){
		super();
	}
	
	public KNNRunConfig(int dataSetConfigId, int [] columnsToUse, int predictionColumn, int [] splitPoints, String formula, int k){
		super(dataSetConfigId, columnsToUse, predictionColumn, splitPoints, formula);
		this.k = k;
	}
	
	public int getK(){
		return k;
	}
}
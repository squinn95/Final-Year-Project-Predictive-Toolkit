package project.model;
import project.util.*;

public class RunResult{

	private int id; //id of this result
	private int dataSetConfigId; //id of associated dataset
	private int tests;
	private int successful;
	private AlgorithmType algorithm; 
	
	//config fields 
	private int [] columnsToUse;
	private int predictionColumn;
	private int [] splitPoints;
	
	//config: NC, DT & KNN only
	private String formula;
	
	//config: KNN only
	private int k;
	
	public RunResult(int tests, int successful, AlgorithmType algorithm ){
		this.tests = tests;
		this.successful = successful;
		this.algorithm = algorithm;
	}

	public void setId(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
	
	public void setDataSetConfigId(int dataSetConfigId){
		this.dataSetConfigId = dataSetConfigId;
	}
	
	public int getDataSetConfigId(){
		return dataSetConfigId;
	}
	
	public int getTests(){
		return tests;
	}
	
	public int getSuccessful(){
		return successful;
	}
	
	public AlgorithmType getAlgorithm(){
		return algorithm;
	}
	
	public void setColumnsToUse(int [] columnsToUse){
		this.columnsToUse = columnsToUse;
	}
	
	public int [] getColumnsToUse(){
		return columnsToUse;
	}
	
	public void setSplitPoints(int [] splitPoints){
		this.splitPoints = splitPoints;
	}
	
	public int [] getSplitPoints(){
		return splitPoints;
	}
	
	public void setPredictionColumn(int predictionColumn){
		this.predictionColumn = predictionColumn;
	}
	
	public int getPredictionColumn(){
		return predictionColumn;
	}
	
	public void setK(int k){
		this.k = k;
	}
	
	public int getK(){
		return k;
	}
	
	public void setFormula(String formula){
		this.formula = formula;
	}
	
	public String getFormula(){
		return formula;
	}

}
package project.model;

public class FormulaRunConfig extends RunConfig{ //Decision Tree & Nearest Centroid
	
	private String formula;
	
	public FormulaRunConfig(){
		super();
	}
	
	public FormulaRunConfig(int dataSetConfigId, int [] columnsToUse, int predictionColumn, int [] splitPoints, String formula){
		super(dataSetConfigId, columnsToUse, predictionColumn, splitPoints);
		this.formula = formula;
	}
	
	public String getFormula(){
		return formula;
	}
}
package project.model;

public class DataSetConfig{

	private boolean partitionTrainSet;
	private boolean headings;
	private String encodedTrainSet;
	private String encodedValidationSet;
	private String name;
	
	public DataSetConfig(){
		super();
	}
	
	public DataSetConfig(boolean partitionTrainSet, String encodedTrainSet, String encodedValidationSet, boolean headings, String name){
		this.partitionTrainSet = partitionTrainSet;
		this.encodedTrainSet = encodedTrainSet;
		this.encodedValidationSet = encodedValidationSet;
		this.headings = headings;
		this.name = name;
	}
	
	public String getEncodedTrainSet(){
		return encodedTrainSet;
	}
	
	public String getEncodedValidationSet(){
		return encodedValidationSet;
	}
	
	public boolean getPartitionTrainSet(){
		return partitionTrainSet;
	}
	
	public boolean getHeadings(){
		return headings;
	}
	
	public String getName(){
		return name;
	}
	
}
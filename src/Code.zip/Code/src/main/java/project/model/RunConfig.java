package project.model;

public class RunConfig{ //Bayes
	private int dataSetConfigId;
	private int [] columnsToUse;
	private int predictionColumn;
	private int [] splitPoints;

	public RunConfig(){
		super();
	}
	
	public RunConfig(int dataSetConfigId, int [] columnsToUse, int predictionColumn, int [] splitPoints){
		this.dataSetConfigId = dataSetConfigId;
		this.columnsToUse = columnsToUse;
		this.predictionColumn = predictionColumn;
		this.splitPoints = splitPoints;
	}
	
	public int getDataSetConfigId(){
		return dataSetConfigId;
	}
	
	public int [] getColumnsToUse(){
		return columnsToUse;
	}
	
	public int getPredictionColumn(){
		return predictionColumn;
	}
	
	public int [] getSplitPoints(){
		return splitPoints;
	}
}
package project.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import project.model.*;
import project.service.*;

@RestController
@RequestMapping("/api")
public class RestApiController {

	@Autowired
	private AlgorithmService service; // Service which will do all data
								// retrieval/manipulation work

	// -------------------Retrieve All Results--------
	
	@RequestMapping(value = "/results/", method = RequestMethod.GET, produces = { "application/json", "text/json" })
	public ResponseEntity<List<RunResult>> listAllResults() {
		List<RunResult> results = service.getResults();
		if (results.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		else{
			return new ResponseEntity<List<RunResult>>(results, HttpStatus.OK);
		}
	}

	// -------------------Retrieve All datasets--------

	@RequestMapping(value = "/datasets/", method = RequestMethod.GET, produces = { "application/json", "text/json" })
	public ResponseEntity<List<DataSet>> listAlldatasets() {
		List<DataSet> results = service.getDataSets();
		if (results.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else{
			return new ResponseEntity<List<DataSet>>(results, HttpStatus.OK);
		}
	}
	
	// -------------------Retrieve single dataset--------

		@RequestMapping(value = "/datasets/{id}", method = RequestMethod.GET, produces = { "application/json", "text/json" })
		public ResponseEntity<DataSet> getDataset(@PathVariable("id") int id) {
			DataSet set = service.getData(id);
			if (set == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			else{
				return new ResponseEntity<DataSet>(set, HttpStatus.OK);
			}
		}

	// ------------------- Delete All
	// Results---------------------------------------------

	@RequestMapping(value = "/results/", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteAllResults() {
		service.deleteAllRuns();
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	// ------------------- Delete Single
	// Dataset---------------------------------------------

	@RequestMapping(value = "/datasets/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteDataset(@PathVariable("id") int id) {

		boolean successfull = service.deleteFile(id);

		if (successfull == false) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		else{
			return new ResponseEntity<DataSet>(HttpStatus.OK);
		}
	}

	// -------------------Run
	// Algorithms--------------------------------------------------

	@RequestMapping(value = "/KNNEngine/", method = RequestMethod.POST)
	public ResponseEntity<?> createKNNResult(@RequestBody KNNRunConfig config, UriComponentsBuilder ucBuilder) {
		
		try{
			HttpHeaders headers = new HttpHeaders();
			int id = service.runKNN(config);
			headers.setLocation(ucBuilder.path("/api/results/{id}").buildAndExpand(id).toUri());
			return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@RequestMapping(value = "/NBEngine/", method = RequestMethod.POST)
	public ResponseEntity<?> createNBResult(@RequestBody RunConfig config, UriComponentsBuilder ucBuilder) {
		
		try{
			HttpHeaders headers = new HttpHeaders();
			int id = service.runNB(config);
			headers.setLocation(ucBuilder.path("/api/results/{id}").buildAndExpand(id).toUri());
			return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@RequestMapping(value = "/NCEngine/", method = RequestMethod.POST)
	public ResponseEntity<?> createNCResult(@RequestBody FormulaRunConfig config, UriComponentsBuilder ucBuilder) {
		
		try{
			HttpHeaders headers = new HttpHeaders();
			int id = service.runNC(config);
			headers.setLocation(ucBuilder.path("/api/results/{id}").buildAndExpand(id).toUri());
			return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	@RequestMapping(value = "/DTEngine/", method = RequestMethod.POST)
	public ResponseEntity<?> createDTResult(@RequestBody FormulaRunConfig config, UriComponentsBuilder ucBuilder) {
				
		try{
			HttpHeaders headers = new HttpHeaders();
			int id = service.runDT(config);
			headers.setLocation(ucBuilder.path("/api/results/{id}").buildAndExpand(id).toUri());
			return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}

	// -------------------Create dataset---------
	
	@RequestMapping(value = "/datasets/", method = RequestMethod.POST)
	public ResponseEntity<?> createDataSet(@RequestBody DataSetConfig config, UriComponentsBuilder ucBuilder) {

		try{
			HttpHeaders headers = new HttpHeaders();
			int id = service.createFile(config);
			headers.setLocation(ucBuilder.path("/api/datasets/{id}").buildAndExpand(id).toUri());
			return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
		
	}
}
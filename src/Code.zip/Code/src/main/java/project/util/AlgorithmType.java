package project.util;

public enum AlgorithmType {
    KNN, NB, NC, DT 
}
package project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages={"project"})// same as @Configuration @EnableAutoConfiguration @ComponentScan combined
public class PredictiveApp {

	public static void main(String[] args) {
		SpringApplication.run(PredictiveApp.class, args);
	}
}

package project.service;

import java.util.*;
import org.springframework.stereotype.Service;
import project.model.*;
import project.algorithm.*;
import project.util.*;

@Service("service")
public class AlgorithmService{

	private static List<DataSet> datasets;
	private static List<RunResult> results;
	private static int datasetIdCounter;
	private static int runIdCounter;
	
	static{
		datasets = new ArrayList<DataSet>();
		results = new ArrayList<RunResult>();
		datasetIdCounter = 1;
		runIdCounter = 1;
	}
	
	public DataSet getData(int id){
		for(DataSet current : datasets){
			if(current.getId() == id){
				return current;
			}
		}
		return null;
	}
	
	public boolean runExists(int id){
		for(RunResult current : results){
			if(current.getId() == id){
				return true;
			}
		}
		return false;
	}
	
	public void deleteAllRuns(){
		results.clear();
		runIdCounter = 1;
	}
	
	//run knn - POST
	
	public int runKNN(KNNRunConfig config) {

		DataSet dataToUse = getData(config.getDataSetConfigId());
		RunResult result = KNN.predictClassKNN(dataToUse, config.getColumnsToUse(), config.getPredictionColumn(), config.getSplitPoints(), config.getK(), config.getFormula());
		result.setId(runIdCounter);
		result.setDataSetConfigId(config.getDataSetConfigId());

		result.setColumnsToUse(config.getColumnsToUse());
		result.setPredictionColumn(config.getPredictionColumn());
		result.setSplitPoints(config.getSplitPoints());
		result.setFormula(config.getFormula());
		result.setK(config.getK());

		results.add(result);
		runIdCounter++;
		return result.getId();
	}
	
	//run DT - POST
	
	public int runDT(FormulaRunConfig config){
		
		DataSet dataToUse = getData(config.getDataSetConfigId());
		RunResult result = DecisionTree.predictClassDecisionTree(dataToUse, config.getColumnsToUse(), config.getPredictionColumn(), config.getSplitPoints(), config.getFormula());
		result.setId(runIdCounter);
		result.setDataSetConfigId(config.getDataSetConfigId());
		result.setColumnsToUse(config.getColumnsToUse());
		result.setPredictionColumn(config.getPredictionColumn());
		result.setSplitPoints(config.getSplitPoints());
		result.setFormula(config.getFormula());
		results.add(result);
		runIdCounter++;
		return result.getId();
	}
	
	//run NB - POST
	
	public int runNB(RunConfig config){
		DataSet dataToUse = getData(config.getDataSetConfigId());
		RunResult result = Bayes.predictClassBayes(dataToUse, config.getColumnsToUse(), config.getPredictionColumn(), config.getSplitPoints());
		result.setId(runIdCounter);
		result.setDataSetConfigId(config.getDataSetConfigId());
			
		result.setColumnsToUse(config.getColumnsToUse());
		result.setPredictionColumn(config.getPredictionColumn());
		result.setSplitPoints(config.getSplitPoints());
			
		results.add(result);
		runIdCounter++;
		return result.getId();
	}
	
	//run NC - POST
	
	public int runNC(FormulaRunConfig config){
		DataSet dataToUse = getData(config.getDataSetConfigId());
		RunResult result = NearestCentroid.predictClassNearestCentroid(dataToUse, config.getColumnsToUse(), config.getPredictionColumn(), config.getSplitPoints(), config.getFormula());
		result.setId(runIdCounter);
		result.setDataSetConfigId(config.getDataSetConfigId());
			
		result.setColumnsToUse(config.getColumnsToUse());
		result.setPredictionColumn(config.getPredictionColumn());
		result.setSplitPoints(config.getSplitPoints());
		result.setFormula(config.getFormula());
			
		results.add(result);
		runIdCounter++;
		return result.getId();
	}
	
	//return results - GET
	
	public List<RunResult> getResults(){
		return results;
	}
	
	//return datasets - GET -- for testing only
	
	public List<DataSet> getDataSets(){
		return datasets;
	}
	
	//delete file - DELETE
	
	public boolean deleteFile(int id){
		for(DataSet current : datasets){
			if(current.getId() == id){
				datasets.remove(current);
				return true;
			}
		}
		return false;
	}
	
	public boolean dataSetExists(int id){
		for(DataSet current : datasets){
			if(current.getId() == id){
				return true;
			}
		}
		return false;
	}
	
	//create file - POST
	public int createFile(DataSetConfig config){
		
		ArrayList<ArrayList<String>> stringTrainSet = CommonMethods.decodeToStringStructure(config.getEncodedTrainSet());
		
		HashMap<String,Integer> headingsMap = CommonMethods.getHeadings(stringTrainSet, config.getHeadings());
		
		ArrayList<ArrayList<String>> stringNumericTrainSet = CommonMethods.convertNonNumericAtts(stringTrainSet, config.getHeadings());
		//also remove headings
		
		ArrayList<ArrayList<Double>> trainSet = CommonMethods.readDoubleStructure(stringNumericTrainSet);
		ArrayList<ArrayList<Double>> validationSet;
		
		//split train set into two if needed
		if(config.getPartitionTrainSet()){
			Pair<ArrayList<ArrayList<Double>>,ArrayList<ArrayList<Double>>> splits = CommonMethods.randomlyHalfSet(trainSet);
			trainSet = splits.getFirst();
			validationSet = splits.getSecond();
		}
		else{
			ArrayList<ArrayList<String>> stringValidationSet = CommonMethods.decodeToStringStructure(config.getEncodedValidationSet());
			ArrayList<ArrayList<String>> stringNumericValidationSet = CommonMethods.convertNonNumericAtts(stringValidationSet, config.getHeadings());
			validationSet = CommonMethods.readDoubleStructure(stringNumericValidationSet);
		}
		DataSet set = new DataSet(trainSet,validationSet,datasetIdCounter,config.getName(),headingsMap);
		datasets.add(set);
		datasetIdCounter++;
		return set.getId();
	}
	
}
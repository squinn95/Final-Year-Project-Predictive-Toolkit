$(document).ready(function() {

    $.ajax({
        url: "http://localhost:8080/PredictiveToolkit/api/datasets/"
    }).then( function(data) {
    	
    	if(data === undefined){
    		addPlaceholder();
    	}
    	else{
	    	for (var i = 0; i < data.length; i++) {
	    		var name = data[i].name;
	    		var id = data[i].id;
	    		var code = '<div class="col-lg-3 dataset" data-name="'+ name +'" data-id="'+ id +'" ><div class="panel panel-primary"><div class="panel-heading"><div class="row"><div class="col-xs-10 text-right"></div><div class="col-xs-2 text-right"><i class="fa fa-times" role ="button" onclick ="deleteTile(this); return false;"></i></div></div></div><div class="panel-body" style = "background-color: #337ab7; color: #fff; border-color: #337ab7;"><div class="row"><div class="col-xs-12"><div style= "font-size: 20px;"><i class="fa fa-bar-chart fa-2x"></i> &nbsp;'+ name + '</div><br></div></div></div><a href="#"><div class="panel-footer" onclick ="runSet(this); return false;"><span class="pull-left">Run Analysis</span><span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span><div class="clearfix"></div></div></a></div></div>';
	    		$("#block").append(code);
	    	}
    	}
    });
    
    $(".btn").mouseup(function(){
	    $(this).blur();
	})
    
});

function deleteTile(elem){
	 var tile = elem.parentNode.parentNode.parentNode.parentNode.parentNode;
	 var container = tile.parentNode;
	 var data = tile.getAttribute("data-id");
	 var id = parseInt(data);
	 var address = 'http://localhost:8080/PredictiveToolkit/api/datasets/' + id;
	 $.ajax
		({
			type: "DELETE",
		    url: address,
		    contentType : 'application/json',
		    success: function () {
		    	//alert("Thanks!"); 
		    }
		})
	 container.removeChild(tile);
	 
	 if(document.getElementsByClassName('dataset').length == 0){
		 addPlaceholder();
	 }	 
}

function runSet(elem) {
	var tile = elem.parentNode.parentNode.parentNode;
   	var id = tile.getAttribute("data-id");
   	var setName = tile.getAttribute("data-name");
   	var address = "configureAlgorithms.html?id="+id+"&name="+setName;
   	location.href = address;
}

function removePlaceholder(){
	var hold = document.getElementsByClassName('placeholder')[0];
	var container = hold.parentNode;
	container.removeChild(hold);
}

function addPlaceholder(){
	var code = '<div class="row placeholder"><div style= "text-align: center; vertical-align: middle; color: #666666;" ><br><h2>Add Data Set to Begin Analysis</h2></div></div>';
	$("#placeContainer").append(code);
}
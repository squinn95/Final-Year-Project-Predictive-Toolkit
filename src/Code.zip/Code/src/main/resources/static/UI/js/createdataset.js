$(document).ready(function() {
	
	$(".btn").mouseup(function(){
	    $(this).blur();
	})
	
	$("[data-toggle=popover]").popover();
	
    document.getElementById('upload').addEventListener('click', function() {
    	clearValidation();
    	var ok = validate();
    	if(ok == true){
	    	var trainSet = document.getElementsByClassName('trainfile')[0].files[0];
	    	var validationSet = null;
	    	var name = $('#fileName').val();
	    	var partitionTrainSet = $('input[name="partition"]:checked').val();
	    	var headings = $('input[name="headings"]:checked').val();
	    	
	    	var trainReader = new FileReader();
	    	trainReader.onload =  function () { 
	    	         trainSet = trainReader.result.split(",")[1]; 
	    	         if(partitionTrainSet == "false"){
	    	 	  		validationSet = document.getElementsByClassName('valfile')[0].files[0]; 
	    	 	  		var valReader = new FileReader();
	    	 	  		valReader.onload = function () {
	    	 	    		validationSet = valReader.result.split(",")[1];
	    	 	    		postDataSet(partitionTrainSet, trainSet, validationSet, headings, name);
	    	 	    	} 
	    	 	  		valReader.readAsDataURL(validationSet);
	    	   	    }
	    	        else{ 
	    	        	postDataSet(partitionTrainSet, trainSet, validationSet, headings, name);
	    	        }
	    	};
	    	trainReader.readAsDataURL(trainSet);
    	}
    });
});


function validate(){
	var result = true;
	
	var trainSet = document.getElementsByClassName('trainfile')[0];;
	if(trainSet.files[0] == undefined){
		trainSet.parentNode.classList.remove('btn-default');
		trainSet.parentNode.classList.add('btn-danger');
		$(trainSet.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a training set</p>');
		result = false;
	}
	else{
		var split = trainSet.files[0].name.split(".");
		var type = split[split.length-1];
		if(type != "csv"){
			trainSet.parentNode.classList.remove('btn-default');
			trainSet.parentNode.classList.add('btn-danger');
			$(trainSet.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a CSV format file</p>');
			result = false;
		}
	}
	
	var name = document.getElementById('fileName');
	
	if(name.value == ""){
		name.parentNode.classList.add('has-error');
		$(name.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Enter a value for name</p>');
		result = false;
	}
	
	var button = document.getElementsByName('headings');
 	var head = null;
 	for(var i = 0; i < button.length; i++){
 		if(button[i].checked){
 			head = button[i].value;
 		}
 	}
 	if(head === null){
 		$(button[0].parentNode.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a value</p>');
 		button[0].parentNode.parentNode.parentNode.classList.add('errorBorder');
		result = false;
 	}
	
	var button = document.getElementsByName('partition');
 	var part = null;
 	for(var i = 0; i < button.length; i++){
 		if(button[i].checked){
 			part = button[i].value;
 		}
 	}
 	
 	if(part != "true"){
	 	if(part === null){
	 		$(button[0].parentNode.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a value</p>');
	 		button[0].parentNode.parentNode.parentNode.classList.add('errorBorder');
			result = false;
	 	}
	 	
	 	var testSet = document.getElementsByClassName('valfile')[0];
	 	if(testSet.files[0] == undefined){
	 		testSet.parentNode.classList.remove('btn-default');
	 		testSet.parentNode.classList.add('btn-danger');
	 		$(testSet.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a test set</p>');
	 		result = false;
	 	}
	 	else{
	 		var split = testSet.files[0].name.split(".");
	 		var type = split[split.length-1];
	 		if(type != "csv"){
	 			testSet.parentNode.classList.remove('btn-default');
	 			testSet.parentNode.classList.add('btn-danger');
	 			$(testSet.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a CSV format file</p>');
	 			result = false;
	 		}
	 	}
	}
	
	return result;
}

function postDataSet(partitionTrainSet, trainSet, validationSet, headings, name) {
	var data = '{"partitionTrainSet": "' + partitionTrainSet + '", "encodedTrainSet" : "' + trainSet + '", "encodedValidationSet": "' + validationSet + '", "headings": "' + headings +  '", "name": "' + name + '"}';
	
	$.ajax
	({
		type: "POST",
	    url: 'http://localhost:8080/PredictiveToolkit/api/datasets/',
	    contentType : 'application/json',
	    data: data,
	    success: function () {
	    	location.href = "data-sets.html";
	    }
	})	
}

function disableTestSet(elem){
	 var container = elem.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	 var field = container.getElementsByClassName('valfile')[0];
	 
	 reset_field($(field));
	 
	 field.disabled = true;
}

function reset_field (e) {
    e.wrap('<form>').parent('form').trigger('reset');
    e.unwrap();
}

function enableTestSet(elem){
	 var container = elem.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	 var field = container.getElementsByClassName('valfile')[0];
	 field.disabled = false;
}

function clearValidation(){
	// clear red text
	$('.addedVal').remove();
	
	//clear red buttons
	var buttons = document.getElementsByClassName('btn-danger');
	if(buttons != undefined){
		var i = buttons.length;
		while(i--){
			buttons[i].classList.add('btn-default');
			buttons[i].classList.remove('btn-danger');
		}
	}
	
	//clear error formating
	var errors = document.getElementsByClassName('has-error');
	if(errors != undefined){
		var i = errors.length;
		while(i--){
			errors[i].classList.remove('has-error');	
		}
	}
	
	//clear red borders
	var borders = document.getElementsByClassName('errorBorder');
	if(borders != undefined){
		var i = borders.length;
		while(i--){
			borders[i].classList.remove('errorBorder');	
		}
	}
}
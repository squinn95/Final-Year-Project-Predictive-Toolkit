var donutList = new Array();
var init = false;
var exiting = false;


$(document).ready(function() {
	
	var vars = getUrlVars();
	var dataSetName = vars["name"];
	var dataSetConfigId = vars["id"];
	dataSetName = dataSetName.split('#')[0];
	dataSetConfigId = dataSetConfigId.split('#')[0];

	var titleCode = '<div class="col-lg-2"></div><div class="col-lg-8"><h1 class="page-header" style="color: #337ab7">'+ dataSetName +'</h1></div><div class="col-lg-2"></div>';
	$("#datatitle").append(titleCode);
	
	$(".btn").mouseup(function(){
	    $(this).blur();
	})
	
	document.getElementById('finish').addEventListener('click', function() {
		exiting = true;
		$.ajax
		({
				type: "DELETE",
			    url: 'http://localhost:8080/PredictiveToolkit/api/results/',
			    contentType : 'application/json',
			    success: function () {
			    	location.href = "../pages/data-sets.html";
			    }
		})
		
	});
	
	$.ajax({
        url: "http://localhost:8080/PredictiveToolkit/api/datasets/" + dataSetConfigId
    }).then(function(headData) {
    	var headings = headData.headingsMap;
    	
    	$.ajax({
            url: "http://localhost:8080/PredictiveToolkit/api/results/"
        }).then(function(data) {
        	
        	var data1 = new Array();
        	
        	for (var i = 0; i < data.length; i++) {
        		
        		//split points
        		var splitPoints = data[i].splitPoints;
    	    	var splitCode = "";
    	    	if (splitPoints != null){
    	    		var splitString = "";
    	    		var sArrayLength = splitPoints.length;
    	        	for (var j = 0; j < sArrayLength -1; j++){
    	        		splitString += columns[j] + ", ";
    	        	}
    	        	splitString = splitString + splitPoints[sArrayLength.length-1];
    	        	splitCode = '<div class="list-group-item"><i class="fa fa-gear fa-fw"></i> ClassificationAttribute Split Points:<div style="float: right">['+ splitString +']</div></div>';
    	    	}
    	    	
    	    	//attributes
    	    	var columns = data[i].columnsToUse;
    	    	var columnString = "";
    	    	var arrayLength = columns.length;
    	    	for (var g = 0; g < arrayLength -1; g++) {
    	    		var stringValue = getKeyByValue(headings,columns[g]);
    	    		if((stringValue.substring(0,1) === "\"")&&(stringValue.substring((stringValue.length-1),stringValue.length) === "\"")){
    	    			stringValue = stringValue.substring(1,(stringValue.length-1));
    	    		}
    	    		columnString += stringValue + ", ";
    	    	}
    	    	var stringValue = getKeyByValue(headings,columns[columns.length-1]);
        		if((stringValue.substring(0,1) === "\"")&&(stringValue.substring((stringValue.length-1),stringValue.length) === "\"")){
        			stringValue = stringValue.substring(1,(stringValue.length-1));
        		}
    	    	columnString += stringValue;
    	    	
    	    	var kcode = "";
    	    	if(data[i].algorithm === "KNN"){
    	    		kcode = '<div class="list-group-item"><i class="fa fa-gear fa-fw"></i> K-Value:<div style="float: right">'+ data[i].k +'</div></div>';	    	
    	    	}
        		
    	    	var formulaCode = "";
    	    	if(data[i].formula != null){
    	    		
    	    		var formulaString;
    	    		
    	    		if(data[i].formula === "euclidean"){ //checked
    	    			formulaString = "Euclidean";
    	    		}
    	    		else if(data[i].formula === "manhattan"){ //checked
    	    			formulaString = "Manhattan";
    	    		}
    	    		else if(data[i].formula === "InfoGain"){ //checked
    	    			formulaString = "Information Gain";
    	    		}
    	    		else if(data[i].formula === "GainRatio"){ //checked
    	    			formulaString = "Gain Ratio";
    	    		}
    	    		else if(data[i].formula === "hamming"){ //checked
    	    			formulaString = "Hamming";
    	    		}
    	    		
    	    		formulaCode = '<div class="list-group-item"><i class="fa fa-gear fa-fw"></i> Formula:<div style="float: right">'+ formulaString +'</div></div>';	    	
    	    	}
    	    	
    	    	// turn algorithm abbreviations into full words
    	    	
    	    	var algorithm;
    	    	if(data[i].algorithm === "KNN"){
    	    		algorithm = "K-Nearest Neighbours";
    	    	}
    	    	else if(data[i].algorithm === "NB"){
    	    		algorithm = "Naive Bayes";
    	    	}
    	    	else if(data[i].algorithm === "DT"){
    	    		algorithm = "Decision Tree";
    	    	}
    	    	else if(data[i].algorithm === "NC"){
    	    		algorithm = "Rocchio";
    	    	}
        	
        		var code = '<div class="row"><div class="col-lg-2"></div><div class="col-lg-8"><div class="panel panel-primary" id = "result'+ data[i].id +'"><div class="panel-heading"><i class="fa fa-gears fa-fw"></i><strong> Result '+ data[i].id +'</strong></div><div class="row"><i class="fa fa-info-circle fa-2x example-popover"style="color: #337ab7; float: right; padding: 7px; padding-right: 2%; outline: none"tabindex="0" data-html="true" role="button" data-toggle="popover"data-placement="left" data-trigger="focus" title="Information"data-content=\'<div style="width: 100%; height: 100%"><div class="col-lg-1"></div><div class="col-lg-10"><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>Accuracy</strong></h4><p>The accuracy measures the percentage of records in the test set which were correctly classified by the classifier built using this configuration and training set.<br><br> Click <ahref="https://en.wikipedia.org/wiki/Accuracy_and_precision"target="_blank">here</a> to learn more about the overall classifier accuracy measure.</p></div></div><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>Attributes used</strong></h4><p>These are the attributes the prediction is based on.</p></div></div><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>Classification Attribute</strong></h4><p>This is the attribute being predicted.</p></div></div><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>(optional) Classification Attribute Split Points</strong></h4><p>These are the values at which the classification was partitioned into classes.</p></div></div><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>(optional) Formula</strong></h4><p>This is the formula used by this algorithm, for a particular aspect of its process.</p></div></div><div class="row"><div class="well well-sm" style="border-color: #337ab7"><h4><strong>(optional) k</strong></h4><p>For a KNN algorithm, this is the number of neighbours used.</p></div></div></div><div class="col-lg-1"></div></div>\'></i></div><div class="row"><div class="col-lg-1"></div><div class="col-lg-6"><div class="panel panel-default"><div class="panel-heading"><p style="text-align: center; margin-bottom: 0;"><strong>Configuration</strong></p></div><div class="list-group"><div class="list-group-item"><i class="fa fa-gear fa-fw"></i> Algorithm:<div style="float: right">' + algorithm + '</div></div><div class="list-group-item"><i class="fa fa-gear fa-fw"></i> Tests Ran:<div style="float: right">'+ data[i].tests +'</div></div><div class="list-group-item clearfix"><div class="col-lg-4" style="padding: 0px"><i class="fa fa-gear fa-fw"></i> Attributes used:</div><div class="col-lg-8" style="padding: 0px"><p style="float: right; margin: 0px" >['+ columnString +']</p></div></div><div class="list-group-item"><i class="fa fa-gear fa-fw"></i> ClassificationAttribute:<div style="float: right">'+ data[i].predictionColumn +'</div></div>'+ splitCode + formulaCode + kcode +'</div></div></div><div class="col-lg-4"><div id="morris-donut-chart'+ data[i].id +'"style="height: 250px; width: 250px; vertical-align: center; margin: 0 auto"></div></div><div class="col-lg-1"></div></div>';
        		
        		$("#block").append(code);
        		$("[data-toggle=popover]").popover();
        		
        		
        		var percentage = (data[i].successful/data[i].tests) * 100;
        		percentage = +percentage.toFixed(2);
        		var donut = drawDonut(percentage, data[i].id);
        		donutList.push(donut);
        		data1.push([data[i].id,percentage])
        	}
        	
        	var fontSize;
        	if(data1.length > 11){
        		fontSize = 10;
        	}
        	else if(data1.length < 8){
        		fontSize = 20;
        	}
        	else{
        		fontSize = 15;
        	}
        	var  chart;
        	var data = [ {
        		data: data1,
        		bars: {
        			show: true,
        			barWidth: 0.5
        		}
        	}];
        	var options = {
        			legend: {
        				position: "nw"
        			},
        			grid: {
        				clickable: true,
        				hoverable: true
        			},
        			xaxis:{
        				tickSize: 1,
        				tickDecimals: 0,
        				axisLabel : 'Result Number',
        				axisLabelPadding: 6
        			},
        			yaxis:{
        				max:100,
        				min:0,
        				axisLabel : 'Accuracy (%)',
        				axisLabelPadding: 6
        			},
        			series: {
        			    color: '#337ab7',
        				bars: {
        					fill: true,
        					numbers: {
        			            show : function(s) { return s.toString() + "%" },
        			            font : {
        			            	size : fontSize,
        			            	style : 'sans-serif'
        			            }  
        			        }
        			    }
        			}        			
        	}
        	
        	chart = $.plot($("#placeholder"), data, options);  	

        	$("#placeholder").bind("plotclick", function (event, pos, item) {       
        		if (item) {
        			location.href = "#result"+(item.dataIndex+1);
        		}
        	});
     
        	init = true;
        });
    });
	
	
});

window.addEventListener("beforeunload", function (event) {
	 if(exiting === false){
		 event.returnValue = "are you sure?";
	 }
	
	  $.ajax
		({
				type: "DELETE",
			    url: 'http://localhost:8080/PredictiveToolkit/api/results/',
			    contentType : 'application/json',
			    success: function () {
			    	
			    }
		})
});

$(document).bind('DOMSubtreeModified', function () {
	if(init === true){
		for(var j = 0; j < donutList.length; j++){
			for(var i = 0; i < donutList[j].segments.length; i++) {
			    // Remove hover handlers:
				donutList[j].segments[i].handlers['hover'] = [];
			}
			try{
				donutList[j].select(undefined);
			}
			catch(e){}
		}
	}
});


Morris.Donut.prototype.redraw = function() {
	  var C, cx, cy, i, idx, last, max_value, min, next, seg, total, value, w, _i, _j, _k, _len, _len1, _len2, _ref, _ref1, _ref2, _results;
	  this.raphael.clear();
	  cx = this.el.width() / 2;
	  cy = this.el.height() / 2;
	  w = (Math.min(cx, cy) - 10) / 3;
	  total = 0;
	  _ref = this.values;
	  for (_i = 0, _len = _ref.length; _i < _len; _i++) {
	    value = _ref[_i];
	    total += value;
	  }
	  min = 5 / (2 * w);
	  C = 1.9999 * Math.PI - min * this.data.length;
	  // ------------ PATCHED: start from the top
	  last = Math.PI;
	  // original:
	  // last = 0
	  // ------------
	  idx = 0;
	  this.segments = [];
	  _ref1 = this.values;
	  for (i = _j = 0, _len1 = _ref1.length; _j < _len1; i = ++_j) {
	    value = _ref1[i];
	    // ------------ PATCHED: change direction of rendering
	    next = last - min - C * (value / total);
	    seg = new Morris.DonutSegment(cx, cy, w * 2, w, next, last, this.data[i].color || this.options.colors[idx % this.options.colors.length], this.options.backgroundColor, idx, this.raphael);
	    // original:
	    // next = last + min + C * (value / total);
	    // seg = new Morris.DonutSegment(cx, cy, w * 2, w, last, next, this.data[i].color || this.options.colors[idx % this.options.colors.length], this.options.backgroundColor, idx, this.raphael);
	    // ------------
	    seg.render();
	    this.segments.push(seg);
	    seg.on('hover', this.select);
	    seg.on('click', this.click);
	    last = next;
	    idx += 1;
	  }
	  this.text1 = this.drawEmptyDonutLabel(cx, cy - 10, this.options.labelColor, 15, 800);
	  this.text2 = this.drawEmptyDonutLabel(cx, cy + 10, this.options.labelColor, 14);
	  max_value = Math.max.apply(Math, this.values);
	  idx = 0;
	  _ref2 = this.values;
	  _results = [];
	  for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
	    value = _ref2[_k];
	    if (value === max_value) {
	      this.select(idx);
	      break;
	    }
	    _results.push(idx += 1);
	  }
	  return _results;
};

function getUrlVars(){
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++){
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function drawDonut(success, id){
	var unsuccess = 100 - success;
	var element = 'morris-donut-chart' + id;
	 
	var donut = new Morris.Donut({
		  element: element,
		  resize: true,
		  labelColor: '#080f19',
		  colors: [
		    '#33c63f',
		    '#D3D3D3'
		  ],
		  data: [
		    {label: "Accuracy", value: success, formatted: success+'%'},
		    {label: "Accuracy", value: unsuccess, formatted: success+'%'},
		  ],
		  formatter: function (x, data) { return data.formatted; }
	});
	
	for(i = 0; i < donut.segments.length; i++) {
	    donut.segments[i].handlers['hover'] = [];
	}
	
	try{
		donut.select(undefined);
	}
	catch(e){}
	
	return donut;	
}

function getKeyByValue(headings, value){
	for(var key in headings) {
	    if(headings[key] === value ){
	    	return key;
	    }
    }
}
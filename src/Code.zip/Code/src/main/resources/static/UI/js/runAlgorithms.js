var dataSetName;
var dataSetConfigId;

$(document).ready(function() {
	
	var vars = getUrlVars();
	dataSetConfigId = vars["id"];
	dataSetName = vars["name"];
	var counter = 0;
	var optionsCode = "";
	
	$.ajax({
        url: "http://localhost:8080/PredictiveToolkit/api/datasets/" + dataSetConfigId
    }).then(function(data) {
	    	for(var key in data.headingsMap){
	    		var keyStr = key;
	    		if((key.substring(0,1) === "\"")&&(key.substring((key.length-1),key.length) === "\"")){
	    			keyStr = key.substring(1,(key.length-1));
	    		}
	    		optionsCode += '<option value = "' + data.headingsMap[key] + '">' + keyStr + '</option>';
	    	}
    });
	
	var titleCode = '<div class="col-lg-2"></div><div class="col-lg-8"><h1 class="page-header" style="color: #337ab7">'+ dataSetName +'</h1></div><div class="col-lg-2"></div>';
	$("#datatitle").append(titleCode);
	
	$(".btn").mouseup(function(){
	    $(this).blur();
	})
	
	document.getElementById('addKNN').addEventListener('click', function() {
		
		if(document.getElementsByClassName('placeholder').length == 1){
			removePlaceholder();
		}
		
		var code = '<div class="row config" data-type="KNN"><div class="col-lg-2"></div><div class="col-lg-8"><div class="panel panel-primary" style="border-color: purple"><div class="panel-heading"style="border-color: purple; background-color: purple">K-Nearest Neighbours <a style="float: right; vertical-align: middle;"onclick="deleteTile(this); return false;"> <i class="fa fa-times " style="color: white" role="button"></i></a></div><div class="row"><i class="fa fa-info-circle fa-2x example-popover"style="color: purple; float: right; padding: 7px; padding-right: 2%; outline: none"tabindex="0" data-html="true" role="button" data-toggle="popover"data-placement="left" data-trigger="focus"title="<b>Information</b>"data-content=\'<div style ="width: 100%; height: 100%"> <div class="col-lg-1"></div> <div class="col-lg-10"> <div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>About K-Nearest Neighbours</strong></h4> <p>This classifier works with both continuous and discrete valued attributes.<br><br> Click <a href="https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm" target="_blank">here</a> to learn more about how K-Nearest Neighbour Classifiers work. </p> </div> </div> <div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>Attributes to use</strong></h4><p>Select the attributes you wish to use to build the classifier.</p></div> </div><div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>Classification Attribute</strong></h4> <p>Select the classification Attribute, the attribute you are trying to predict the value of.</p> </div></div><div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>Split Classification Attribute</strong></h4> <p>Select "Yes" if the classification attribute is continuous valued and you wish to partition it into classes.<br><br> Select "No" if the classification attribute is discrete valued. </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>Split Points</strong></h4> <p>This option will only be available if you selected "Yes" for split classification attribute.<br><br> Enter the values you wish to split the attribute on. i.e. if the attribute has values (0-20) entering "7,14" will create 3 classes with values (0-6),(7-13),(14-20).<br><br> Enter the values as a comma separated list in format: "0,1,2,3,4,5". </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>Formula</strong></h4> <p>Select the formula you wish the classifier to use to calculate the distance between neighbours.</p> </div></div><div class="row"> <div class="well well-sm"style="border-color: purple"> <h4><strong>K Value</strong></h4> <p>Enter the number of neighbours you wish the classifier to use.<br><br> Enter a single numeric value. i.e."5" </p> </div></div></div><div class="col-lg-1"></div></div>\'></i></div><div class="row"><div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">Attributes to use:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker atts" multiple>'+ optionsCode +'</select></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Classification Attribute:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker pred"><option disabled selected value>Nothing selected</option>'+ optionsCode +'</select></div></div></div></div><br><div class="row"><div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">Formula:</label><div class="col-md-4 col-sm-9 col-xs-8"><h3 style="margin-top: 0px; margin-bottom: 0px"><small>Continuous data</small></h3><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="euclidean">Euclidean</label></div><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="manhattan">Manhattan</label></div></div><div class="col-md-4 col-sm-9 col-xs-8"><h3 style="margin-top: 0px; margin-bottom: 0px"><small>Categorical data</small></h3><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="hamming">Hamming</label></div></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Classification Attribute:</label><div class="col-md-4 col-sm-9 col-xs-8"><div class="radio"><label> <input type="radio" name="split'+ counter +'"class="split" value="yes" onclick="enableSplit(this);">Yes</label></div><div class="radio"><label> <input type="radio" name="split'+ counter +'"class="split" value="no" onclick="disableSplit(this);">No</label></div></div></div></div></div><br><div class="row"><div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">K Value:</label><div class="col-md-4 col-sm-9 col-xs-8"><input class="form-control k"></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Points:</label><div class="col-md-4 col-sm-9 col-xs-8"><input class="form-control splitslist" disabled></div></div></div></div><br><div class="row"><i class="fa fa-file-code-o fa-2x" onclick="populate(this)"style="color: purple; float: right; padding: 7px; padding-right: 2%; outline: none" role="button" title="Copy this configuration to other tiles"></i></div></div></div><div class="col-lg-2"></div></div>';
		$("#block").append(code);
		$(".selectpicker").selectpicker();
		$("[data-toggle=popover]").popover();
		$(".btn").mouseup(function(){
		    $(this).blur();
		})
		counter++;
	});
	
	document.getElementById('addNB').addEventListener('click', function() {
		
		if(document.getElementsByClassName('placeholder').length == 1){
			removePlaceholder();
		}
	    	
		var code = '<div class="row config" data-type="NB"> <div class="col-lg-2"> </div> <div class="col-lg-8"> <div class="panel panel-yellow"> <div class="panel-heading"> Naive Bayes <a style= "float: right; vertical-align: middle;" onclick ="deleteTile(this); return false;" > <i class="fa fa-times " style="color:white" role="button" ></i></a> </div> <div class="row"> <i class="fa fa-info-circle fa-2x example-popover" style="color:#f0ad4e; float: right; padding: 7px; padding-right: 2%; outline: none" tabindex="0" data-html="true" role="button" data-toggle="popover" data-placement="left" data-trigger="focus" title="<b>Information</b>" data-content=\'<div style ="width: 100%; height: 100%"> <div class="col-lg-1"></div> <div class="col-lg-10"> <div class="row"> <div class="well well-sm"style="border-color: #f0ad4e"> <h4><strong>About Naive Bayes</strong></h4> <p>This Naive Bayes classifier will only work with discrete valued attributes (With Exception to the classification attribute, which can be partitioned into classes.)<br><br> Click <a href="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" target="_blank">here</a> to learn more about how Naive Bayes Classifiers work. </p> </div> </div> <div class="row"> <div class="well well-sm"style="border-color: #f0ad4e"> <h4><strong>Attributes to use</strong></h4> <p>Select the attributes you wish to use to build the classifier.</p> </div> </div><div class="row"> <div class="well well-sm"style="border-color: #f0ad4e"> <h4><strong>Classification Attribute</strong></h4> <p>Select the classification Attribute, the attribute you are trying to predict the value of.</p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #f0ad4e"> <h4><strong>Split Classification Attribute</strong></h4> <p>Select "Yes" if the classification attribute is continuous valued and you wish to partition it into classes.<br><br> Select "No" if the classification attribute is discrete valued. </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #f0ad4e"> <h4><strong>Split Points</strong></h4> <p>This option will only be available if you selected "Yes" for split classification attribute.<br><br> Enter the values you wish to split the attribute on. i.e. if the attribute has values (0-20) entering "7,14" will create 3 classes with values (0-6),(7-13),(14-20).<br><br> Enter the values as a comma separated list in format: "0,1,2,3,4,5". </p> </div></div></div><div class="col-lg-1"></div></div>\' ></i> </div> <div class="row"><div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">Attributes to use:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker atts" multiple>'+ optionsCode +'</select></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Classification Attribute:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker pred"><option disabled selected value>Nothing selected</option>'+ optionsCode +'</select></div></div></div></div> <br> <div class="row"> <div class="col-lg-6"> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Classification Attribute:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="yes" onclick ="enableSplit(this);">Yes </label> </div> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="no" onclick ="disableSplit(this);" >No </label> </div> </div> </div> </div> </div> <br> <div class="row"> <div class="col-lg-6"> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Points:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <input class="form-control splitslist"disabled> </div> </div> </div> </div> <br><div class="row"><i class="fa fa-file-code-o fa-2x" onclick="populate(this)"style="color: #f0ad4e; float: right; padding: 7px; padding-right: 2%; outline: none" role="button" title="Copy this configuration to other tiles"></i></div></div> </div> <div class="col-lg-2"> </div> </div>';
		$("#block").append(code);
		$(".selectpicker").selectpicker();
		$("[data-toggle=popover]").popover();
		counter++;
	});
	
	document.getElementById('addNC').addEventListener('click', function() {
		
		if(document.getElementsByClassName('placeholder').length == 1){
			removePlaceholder();
		}
		
		var code = '<div class="row config" data-type="NC"> <div class="col-lg-2"> </div> <div class="col-lg-8"> <div class="panel panel-green"> <div class="panel-heading"> Rocchio <a style= "float: right; vertical-align: middle;" onclick ="deleteTile(this); return false;" > <i class="fa fa-times " role="button" style="color:white" ></i></a> </div> <div class="row"> <i class="fa fa-info-circle fa-2x example-popover" style="color:#5cb85c; float: right; padding: 7px; padding-right: 2%; outline: none" tabindex="0" data-html="true" role="button" data-toggle="popover" data-placement="left" data-trigger="focus" title="<b>Information</b>" data-content=\'<div style ="width: 100%; height: 100%"> <div class="col-lg-1"></div> <div class="col-lg-10"> <div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>About Rocchio Classifier</strong></h4> <p>This classifier works with both continuous and discrete valued attributes.<br><br> Click <a href="https://en.wikipedia.org/wiki/Nearest_centroid_classifier" target="_blank">here</a> to learn more about how Rocchio Classifiers work. </p> </div> </div> <div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>Attributes to use</strong></h4> <p>Select the attributes you wish to use to build the classifier.</p> </div> </div><div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>Classification Attribute</strong></h4> <p>Select the classification Attribute, the attribute you are trying to predict the value of.</p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>Split Classification Attribute</strong></h4> <p>Select "Yes" if the classification attribute is continuous valued and you wish to partition it into classes.<br><br> Select "No" if the classification attribute is discrete valued. </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>Split Points</strong></h4> <p>This option will only be available if you selected "Yes" for split classification attribute.<br><br> Enter the values you wish to split the attribute on. i.e. if the attribute has values (0-20) entering "7,14" will create 3 classes with values (0-6),(7-13),(14-20).<br><br> Enter the values as a comma separated list in format: "0,1,2,3,4,5". </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #5cb85c"> <h4><strong>Formula</strong></h4> <p>Select the formula you wish the classifier to use to calculate the distance from the centroids.</p> </div></div></div><div class="col-lg-1"></div></div>\' ></i> </div><div class="row"> <div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">Attributes to use:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker atts" multiple>'+ optionsCode +'</select></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Classification Attribute:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker pred"><option disabled selected value>Nothing selected</option>'+ optionsCode +'</select></div></div></div></div> <br> <div class="row"> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-3 col-sm-3 col-xs-3 control-label">Formula:</label><div class="col-md-4 col-sm-9 col-xs-8"><h3 style="margin-top: 0px; margin-bottom: 0px"><small>Continuous data</small></h3><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="euclidean">Euclidean</label></div><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="manhattan">Manhattan</label></div></div><div class="col-md-4 col-sm-9 col-xs-8"><h3 style="margin-top: 0px; margin-bottom: 0px"><small>Categorical data</small></h3><div class="radio"><label> <input type="radio"name="formula'+ counter +'" class="formula" value="hamming">Hamming</label></div></div> </div> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Classification Attribute:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="yes" onclick ="enableSplit(this);">Yes </label> </div> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="no" onclick ="disableSplit(this);">No </label> </div> </div> </div> </div> </div> <br> <div class="row"> <div class="col-lg-6"> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Points:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <input class="form-control splitslist"disabled> </div> </div> </div> </div> <br> <div class="row"><i class="fa fa-file-code-o fa-2x" onclick="populate(this)"style="color: #5cb85c; float: right; padding: 7px; padding-right: 2%; outline: none" role="button" title="Copy this configuration to other tiles"></i></div></div> </div> <div class="col-lg-2"> </div> </div>';
		$("#block").append(code);
		$(".selectpicker").selectpicker();
		$("[data-toggle=popover]").popover();
		counter++;
	});
	
	document.getElementById('addDT').addEventListener('click', function() {
		
		if(document.getElementsByClassName('placeholder').length == 1){
			removePlaceholder();
		}
		
		var code = '<div class="row config" data-type="DT"> <div class="col-lg-2"> </div> <div class="col-lg-8"> <div class="panel panel-red"> <div class="panel-heading"> Decision Tree <a style= "float: right; vertical-align: middle;" onclick ="deleteTile(this); return false;" > <i class="fa fa-times " style="color:white" role="button"></i></a> </div> <div class="row"> <i class="fa fa-info-circle fa-2x example-popover" style="color:#d9534f; float: right; padding: 7px; padding-right: 2%; outline: none" tabindex="0" data-html="true" role="button" data-toggle="popover" data-placement="left" data-trigger="focus" title="<b>Information</b>" data-content=\'<div style ="width: 100%; height: 100%"> <div class="col-lg-1"></div> <div class="col-lg-10"> <div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>About Decision Tree</strong></h4> <p>This Decision Tree will only work with discrete valued attributes (With Exception to the classification attribute, which can be partitioned into classes.)<br><br> Click <a href="https://en.wikipedia.org/wiki/Decision_tree_learning" target="_blank">here</a> to learn more about how Decision Tree Classifiers work. </p> </div> </div> <div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>Attributes to use</strong></h4> <p>Select the attributes you wish to use to build the classifier.</p> </div> </div><div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>Classification Attribute</strong></h4> <p>Select the classification Attribute, the attribute you are trying to predict the value of.</p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>Split Classification Attribute</strong></h4> <p>Select "Yes" if the classification attribute is continuous valued and you wish to partition it into classes.<br><br> Select "No" if the classification attribute is discrete valued. </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>Split Points</strong></h4> <p>This option will only be available if you selected "Yes" for split classification attribute.<br><br> Enter the values you wish to split the attribute on. i.e. if the attribute has values (0-20) entering "7,14" will create 3 classes with values (0-6),(7-13),(14-20).<br><br> Enter the values as a comma separated list in format: "0,1,2,3,4,5". </p> </div></div><div class="row"> <div class="well well-sm"style="border-color: #d9534f"> <h4><strong>Formula</strong></h4> <p>Select the formula you wish the classifier to use when choosing which attribute to split on.</p> </div></div></div><div class="col-lg-1"></div></div>\' ></i> </div><div class="row"> <div class="col-lg-6"><div class="form-group"><label class="col-md-3 col-sm-3 col-xs-3 control-label">Attributes to use:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker atts" multiple>'+ optionsCode +'</select></div></div></div><div class="col-lg-6"><div class="form-group"><label class="col-md-4 col-sm-4 col-xs-4 control-label">Classification Attribute:</label><div class="col-md-4 col-sm-9 col-xs-8"><select class="selectpicker pred"><option disabled selected value>Nothing selected</option>'+ optionsCode +'</select></div></div></div></div> <br> <div class="row"> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-3 col-sm-3 col-xs-3 control-label">Formula:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <div class="radio"> <label> <input type="radio" name = "formula'+ counter +'" class="formula" value="InfoGain">Information Gain </label> </div> <div class="radio"> <label> <input type="radio" name = "formula'+ counter +'" class="formula" value="GainRatio">Gain Ratio </label> </div> </div> </div> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Classification Attribute:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="yes" onclick ="enableSplit(this);">Yes </label> </div> <div class="radio"> <label> <input type="radio" name="split'+ counter +'" class="split" value="no" onclick ="disableSplit(this);">No </label> </div> </div> </div> </div> </div> <br> <div class="row"> <div class="col-lg-6"> </div> <div class="col-lg-6"> <div class="form-group"> <label class="col-md-4 col-sm-4 col-xs-4 control-label">Split Points:</label> <div class="col-md-4 col-sm-9 col-xs-8"> <input class="form-control splitslist"disabled> </div> </div> </div> </div> <br> <div class="row"><i class="fa fa-file-code-o fa-2x" onclick="populate(this)"style="color: #d9534f; float: right; padding: 7px; padding-right: 2%; outline: none" role="button" title="Copy this configuration to other tiles"></i></div></div> </div> <div class="col-lg-2"> </div> </div>';
		$("#block").append(code);
		$(".selectpicker").selectpicker();
		$("[data-toggle=popover]").popover();
		counter++;
	});
	
	document.getElementById('run').addEventListener('click', function() {
    	var configs = document.getElementsByClassName('config');
    	clearValidation();
    	var ok = validate(configs);
    	if(ok == true){
    		run(configs, dataSetConfigId);
    		setTimeout(checkFinished, 100, configs.length);
		}
    }); 
});

function checkFinished(numRuns){
	
	$.ajax({
        url: "http://localhost:8080/PredictiveToolkit/api/results/"
    }).then(function(data) {
    	if(data != undefined){
    		if(numRuns == data.length){
    			location.href = "../pages/displayresults.html?name="+dataSetName+"&id="+dataSetConfigId;
    		}
    	}
    });

	setTimeout(checkFinished, 10, numRuns);
}

function validate(elements){
	var result = true;
	for (var a = 0; a < elements.length; a++){
	 	 
		var predictionColumnElem = elements[a].getElementsByClassName('pred')[0];
	 	var predictionColumn = $(predictionColumnElem).find("option:selected").val();
	 	
	 	if(predictionColumn === ""){
	 		predictionColumnElem.classList.add('errorBorder');
	 		$(predictionColumnElem.parentNode.parentNode.parentNode).append('<div class ="addedVal"><br><p style="color:red" >Select a value</p></div>');
	 	}
	 	
	 	var attributesElem = elements[a].getElementsByClassName('atts')[0];
	 	var targets = [];
	 	$.each($(attributesElem).find("option:selected"), function(){
	 		targets.push($(this).val());
	 	});
	 	var attributes = JSON.stringify(targets);
	 	
	 	if(attributes === "[]"){
	 		attributesElem.classList.add('errorBorder');
	 		$(attributesElem.parentNode.parentNode.parentNode).append('<div class ="addedVal"><br><p style="color:red" >Select a value</p></div>');
	 	}
	 	
		var button = elements[a].getElementsByClassName('split');
     	var split = null;
     	for(var i = 0; i < button.length; i++){
     		if(button[i].checked){
     			split = button[i].value;
     		}
     	}
     	
     	if(split === null){
     		$(button[0].parentNode.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a value</p>');
     		button[0].parentNode.parentNode.parentNode.classList.add('errorBorder');
			result = false;
     	}
     	else if(split == "yes"){
     		splitPoints = elements[a].getElementsByClassName('splitslist')[0];
     		var splitsFormat = splitPoints.value.match(/^\d+(,\d+)*$/);
     		
     		if(splitPoints.value == ""){
     			splitPoints.parentNode.classList.add('has-error');
    			$(splitPoints.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Enter values</p>');
    			result = false;
    		}
     		else if(splitsFormat === null){
     			splitPoints.parentNode.classList.add('has-error');
    			$(splitPoints.parentNode).append('<p style="color:red" class ="addedVal">Enter a list of comma seperated numbers e.g. "1,2,3,4,5"</p>');
    			result = false;
    		}	
     	}
     	
     	var type = elements[a].getAttribute("data-type");
     	
     	if(type != "NB"){
     		var formbutton = elements[a].getElementsByClassName('formula');
   		  	var formula = null;
   		  	for(var i = 0; i < formbutton.length; i++){
   			  if(formbutton[i].checked){
   				  formula = formbutton[i].value;
   			  }
	     	}
   		  	if(formula === null){
   		  		$(formbutton[0].parentNode.parentNode.parentNode).append('<p style="color:red" class ="addedVal">Select a value</p>');
   		  		formbutton[0].parentNode.parentNode.parentNode.classList.add('errorBorder');
      			result = false;
   		  	}
     	}
     	
     	if(type == "KNN"){
     		var k = elements[a].getElementsByClassName('k')[0];
     		if(k.value == ""){
     			k.parentNode.classList.add('has-error');
    			$(k.parentNode).append('<p style="color:red" class ="addedVal">Enter a value</p>');
    			result = false;
    		}
     		else if(isNaN(k.value)){
     			k.parentNode.classList.add('has-error');
    			$(k.parentNode).append('<p style="color:red" class ="addedVal">Enter a single numeric value e.g. "6"</p>');
    			result = false;
    		}
     	}	
	}
	return result;
}

function run(elements, dataSetConfigId){
	
	for (var a = 0; a < elements.length; a++){ 
 	    
     	var type = elements[a].getAttribute("data-type");
     	
     	var predictionColumn = elements[a].getElementsByClassName('pred')[0];
	 	predictionColumn = $(predictionColumn).find("option:selected").val();
	 	
	 	var attributes = elements[a].getElementsByClassName('atts')[0];
	 	var targets = [];
	 	$.each($(attributes).find("option:selected"), function(){
	 		targets.push($(this).val());
	 	});
	 	attributes = JSON.stringify(targets);
     	
     	var button = elements[a].getElementsByClassName('split');
     	var split;
     	for(var i = 0; i < button.length; i++){
     		if(button[i].checked){
     			split = button[i].value;
     		}
     	}

 	   var splitPoints = null;
 	   if(split == "yes"){
 		  splitPoints = elements[a].getElementsByClassName('splitslist')[0].value;
 		  var splitArray = splitPoints.split(",");
 		  splitPoints = JSON.stringify(splitArray);
 	   }
 	  
 	  if(type == "NB"){
 		 var data = '{"dataSetConfigId": "' + dataSetConfigId + '", "columnsToUse" : ' + attributes + ', "predictionColumn": "' + predictionColumn + '", "splitPoints": ' + splitPoints + '}';
 		 var url ='http://localhost:8080/PredictiveToolkit/api/NBEngine/';
 		 postConfig(data, url);
 	  }
 	  else{
 		  var formbutton = elements[a].getElementsByClassName('formula');
 		  var formula;
 		  for(var i = 0; i < formbutton.length; i++){
 			  if(formbutton[i].checked){
 				  formula = formbutton[i].value;
     		  }
     	  }
 		  if(type == "DT"){
 			  var data = '{"dataSetConfigId": "' + dataSetConfigId + '", "columnsToUse" : ' + attributes + ', "predictionColumn": "' + predictionColumn + '", "splitPoints": ' + splitPoints +  ', "formula": "' + formula + '"}';
 			 var url ='http://localhost:8080/PredictiveToolkit/api/DTEngine/';
 			 postConfig(data, url);
 		  }
 		  else if(type == "NC"){
 			 var data = '{"dataSetConfigId": "' + dataSetConfigId + '", "columnsToUse" : ' + attributes + ', "predictionColumn": "' + predictionColumn + '", "splitPoints": ' + splitPoints +  ', "formula": "' + formula + '"}';
 			 var url ='http://localhost:8080/PredictiveToolkit/api/NCEngine/';
 			 postConfig(data, url);
 		  }
 		  else{ //KNN
 			  var k = elements[a].getElementsByClassName('k')[0].value;
 			  var data = '{"dataSetConfigId": "' + dataSetConfigId + '", "columnsToUse" : ' + attributes + ', "predictionColumn": "' + predictionColumn + '", "splitPoints": ' + splitPoints +  ', "formula": "' + formula +  '", "k": "' + k + '"}';
 			  var url ='http://localhost:8080/PredictiveToolkit/api/KNNEngine/';
 			  postConfig(data, url);
 		 }
 	  }	   	
 	}
}

function postConfig(data, url) {
	$.ajax
	({
		type: "POST",
	    url: url,
	    contentType : 'application/json',
	    data: data,
	    success: function () {
	    	//alert("Thanks!"); 
	    }
	})
}

function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function deleteTile(elem){
	 var tile = elem.parentNode.parentNode.parentNode.parentNode;
	 var container = tile.parentNode;
	 container.removeChild(tile);
	 
	 if(document.getElementsByClassName('config').length == 0){
		addPlaceholder();
	 }
}

function populate(elem){
	var tile = elem.parentNode.parentNode;
	
	var type = tile.getAttribute("data-type");	
 	var predictionColumn = tile.getElementsByClassName('pred')[0]; 	
 	var attributes = tile.getElementsByClassName('atts')[0]; 	
 	var splitButton = tile.getElementsByClassName('split');	
 	var split;
 	for(var i = 0; i < splitButton.length; i++){
 		if(splitButton[i].checked){
 			split = splitButton[i].value;
 		}
 	}
 	var splitPoints = null;
 	if(split === "yes"){
 		splitPoints = tile.getElementsByClassName('splitslist')[0];
 	}
 	if(type === "NB"){
 		replaceAll(type, predictionColumn, attributes, splitButton, splitPoints, null, null);
 	}
 	else{
 		var formbutton = tile.getElementsByClassName('formula');
 		if(type === "KNN"){
 			var k = tile.getElementsByClassName('k')[0];
 			replaceAll(type, predictionColumn, attributes, splitButton, splitPoints, formbutton, k);
 		}
 		else{
 			replaceAll(type, predictionColumn, attributes, splitButton, splitPoints, formbutton, null);
 		}
 	}
}

function replaceAll(type, predictionColumn, attributes, splitButton, splitPoints, formButton, k){
	var elements = document.getElementsByClassName('config');
	
	for (var a = 0; a < elements.length; a++){ 	
		var currentType = elements[a].getAttribute("data-type");
		
	 	var currentPredictionColumn = elements[a].getElementsByClassName('pred')[0]; 
	 	var copyPVal = $(predictionColumn.childNodes[2]).val();
	 	var nodeP = currentPredictionColumn.childNodes[2];
	 	$(nodeP).val(copyPVal);
	 	$('.selectpicker').selectpicker('refresh');
	 	
	 	var currentAttributes = elements[a].getElementsByClassName('atts')[0];
	 	var copyVal = $(attributes.childNodes[2]).val();
	 	var node = currentAttributes.childNodes[2];
	 	$(node).val(copyVal);
	 	$('.selectpicker').selectpicker('refresh');
	 	
	 	var currentSplitButton = elements[a].getElementsByClassName('split');	
	
	 	var split;
	 	for(var i = 0; i < currentSplitButton.length; i++){
	 		currentSplitButton[i].checked = splitButton[i].checked;
	 		if(currentSplitButton[i].checked){
	 			split = currentSplitButton[i].value;
	 		}
	 	}
	 	
	 	if(split === "yes"){
	 		currentSplitPoints = elements[a].getElementsByClassName('splitslist')[0];
	 		currentSplitPoints.disabled = false;
	 		var copySplitVal = $(splitPoints).val();
	 		$(currentSplitPoints).val(copySplitVal);
	 	}
	 	
	 	if((formButton != null) && (currentType === type)){
	 		var currentFormButton = elements[a].getElementsByClassName('formula');
	 		for(var i = 0; i < currentFormButton.length; i++){
	 			currentFormButton[i].checked = formButton[i].checked;
		 	}
	 	}
	 	
	 	if((k != null) && (currentType === type)){
	 		var currentK = elements[a].getElementsByClassName('k')[0];
	 		var copyKVal = $(k).val();
	 		$(currentK).val(copyKVal);	
	 	}		
	}
}

function disableSplit(elem){
	 var container = elem.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	 var field = container.getElementsByClassName('splitslist')[0];
	 field.disabled = true;
}

function enableSplit(elem){
	 var container = elem.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	 var field = container.getElementsByClassName('splitslist')[0];
	 field.disabled = false;
}

function removePlaceholder(){
	var hold = document.getElementsByClassName('placeholder')[0];
	var container = hold.parentNode;
	container.removeChild(hold);
}

function addPlaceholder(){
	var code = '<div class="row placeholder"><div style= "text-align: center; vertical-align: middle; color: #666666;" ><br><h3>Select a Classifier Below to Begin</h3></div></div>';
	$("#placeContainer").append(code);
}

function clearValidation(){
	
	// clear red text
	$('.addedVal').remove();

	//clear error formating
	var errors = document.getElementsByClassName('has-error');
	if(errors != undefined){
		var i = errors.length;
		while(i--){
			errors[i].classList.remove('has-error');	
		}
	}
	
	//clear red borders
	var borders = document.getElementsByClassName('errorBorder');
	if(borders != undefined){
		var i = borders.length;
		while(i--){
			borders[i].classList.remove('errorBorder');	
		}
	}
}